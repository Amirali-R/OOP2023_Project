package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Comment;
import model.Customer;
import model.Food;
import model.Restaurant;

import java.io.IOException;
import java.util.Objects;

public class OpenSelectedRestaurantController {

    @FXML
    private Button btnBack;

    @FXML
    private TextField txtEditRating;

    @FXML
    private ListView<Food> vieListFoods;

    @FXML
    private Label lblWelcome;

    @FXML
    private AnchorPane anchorPaneComments;

    @FXML
    private ListView<String> viewListRatings;

    @FXML
    private TextField txtEditComment;

    @FXML
    private TextField txtAddComment;

    @FXML
    private AnchorPane anchorPaneRatings;

    @FXML
    private AnchorPane anchorPaneFoods;

    @FXML
    private ListView<Comment> vieListComment;

    @FXML
    private TextField txtAddRating;

    @FXML
    private TextField txtSearch;

    @FXML
    void showFoodsPressed(ActionEvent event) {     // Completed
        if (anchorPaneFoods.isVisible())
            anchorPaneFoods.setVisible(false);
        else {
            anchorPaneFoods.setVisible(true);
            vieListFoods.getItems().clear();
            vieListFoods.getItems().addAll(Customer.loggedInRestaurant.getFoods());
        }
        anchorPaneComments.setVisible(false);
        anchorPaneRatings.setVisible(false);
    }

    @FXML
    void showRatingPressed(ActionEvent event) {            //      Completed
        if (anchorPaneRatings.isVisible())
            anchorPaneRatings.setVisible(false);
        else {
            {
                anchorPaneRatings.setVisible(true);
                viewListRatings.getItems().clear();
                for (Comment item :
                        Customer.loggedInRestaurant.getComments()) {
                    viewListRatings.getItems().add("User ID:  "+item.getUserID()+"  Rating :"+item.getRating());
                }
            }
        }
        anchorPaneFoods.setVisible(false);
        anchorPaneComments.setVisible(false);
    }

    @FXML
    void showCommentPressed(ActionEvent event) {      // Completed
        if (anchorPaneComments.isVisible()){
            anchorPaneComments.setVisible(false);
        }
        else {
            anchorPaneComments.setVisible(true);
            vieListComment.getItems().clear();
            vieListComment.getItems().addAll(Customer.loggedInRestaurant.getComments());
        }
        anchorPaneFoods.setVisible(false);
        anchorPaneRatings.setVisible(false);
    }

    @FXML
    void backPressed(ActionEvent event) throws IOException {        // Completed
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("welcomeToCustomer.fxml"));    //   Here we go for Customer
        Scene newScene = new Scene(anchorPane,950,630);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void editCommentPressed(ActionEvent event) {         // Completed
        int index = -1;
        for (int i = 0; i < vieListComment.getItems().size(); i++) {
            if (vieListComment.getSelectionModel().isSelected(i))
                index = i;
        }

        if (index!=-1&&(!txtEditComment.getText().equals("")||!txtEditRating.getText().equals(""))){
            if (this.checkCommentID(vieListComment.getItems().get(index))){
                if (txtEditRating.getText().equals("")) { // Edit comment
                    String newComment = txtEditComment.getText();
                    Customer.loggedInRestaurant.getComments().get(index).setTxt(newComment);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setContentText("Comment Edited Successfully");
                    alert.showAndWait();
                    txtEditComment.setText("");
                    vieListComment.getItems().clear();
                    vieListComment.getItems().addAll(Customer.loggedInRestaurant.getComments());
                } else {
                    String newRate = txtEditRating.getText();
                    Customer.loggedInRestaurant.getComments().get(index).setRating(Integer.parseInt(newRate));
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setContentText("Rating Edited Successfully");
                    alert.showAndWait();
                    txtEditRating.setText("");
                    vieListComment.getItems().clear();
                    vieListComment.getItems().addAll(Customer.loggedInRestaurant.getComments());
                }
            }
            else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("It is not your comment\nyou can't edit this");
                alert.showAndWait();
                txtEditRating.setText("");
            }
        }
    }

    private boolean checkCommentID(Comment comment) {
        if (comment.getUserID().equals(Customer.loggedInCustomer.getUserID()))
            return true;
        return false;
    }

    @FXML
    void addCommentPressed(ActionEvent event) {                                             // completed
        if (!txtAddComment.getText().equals("")&&!txtAddRating.getText().equals("")){
            new Comment(txtAddComment.getText(),Integer.parseInt(txtAddRating.getText()),Customer.loggedInCustomer.getUserID(),false);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Commented Successfully");
            alert.showAndWait();
            txtAddComment.setText("");
            txtAddRating.setText("");
            vieListComment.getItems().clear();
            vieListComment.getItems().addAll(Customer.loggedInRestaurant.getComments());
        }
    }

    @FXML
    void SearchPressed(ActionEvent event) {
        if (!txtSearch.getText().equals("")){
            vieListFoods.getItems().clear();
            for (Food item :
                    Customer.loggedInRestaurant.getFoods()) {
                if (item.getFoodName().equals(txtSearch.getText()))
                    vieListFoods.getItems().add(item);
            }
        }
    }

    @FXML
    void selectFoodPressed(ActionEvent event) throws IOException {
        int index = -1;
        for (int i = 0; i < vieListFoods.getItems().size(); i++) {
            if (vieListFoods.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            Customer.loggedInFood = vieListFoods.getItems().get(index);
            //System.out.println(Customer.loggedInFood.getFoodID());
            Stage stage = (Stage) btnBack.getScene().getWindow();
            stage.close();
            AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("foodSelected.fxml"));    //           Here we go next page
            Scene newScene = new Scene(anchorPane,950,630);
            stage.setScene(newScene);
            stage.show();
        }
    }

    public void showLbl(MouseEvent mouseEvent) {
        lblWelcome.setText("Welcome to restaurant :  "+ Customer.loggedInRestaurant.getName());
    }
}
