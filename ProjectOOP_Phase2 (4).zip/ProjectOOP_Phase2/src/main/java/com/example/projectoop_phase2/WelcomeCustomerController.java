package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Cart;
import model.Customer;
import model.Order;
import model.Restaurant;

import java.io.IOException;

public class WelcomeCustomerController {

    @FXML
    private Label lblChargeAmount;

    @FXML
    private ListView<Restaurant> viewListRestaurants;

    @FXML
    private Button btnSearchFuck;

    @FXML
    private Button btnBack1;

    @FXML
    private Button btnCharge;

    @FXML
    private Button btnSelect;

    @FXML
    private TextField txtCharge2;

    @FXML
    private ListView<Cart> viewListCarts;

    @FXML
    private TextField txtSearch;

    @FXML
    private ListView<Order> viewListOrderHistory;

    @FXML
    private Button btnConfirm;

    @FXML
    void back1Pressed(ActionEvent event) throws IOException {                           // Completed!!!
        Stage stage = (Stage) btnBack1.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));    //           Here we go back
        Scene newScene = new Scene(anchorPane,1086,738);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void showCartStatusPressed(ActionEvent event) {                                      //  Not Complete!!!
        if (btnConfirm.isVisible()){
            btnConfirm.setVisible(false);
            viewListCarts.setVisible(false);
        }
        else {
            btnConfirm.setVisible(true);
            viewListCarts.setVisible(true);

            lblChargeAmount.setVisible(false);

            viewListRestaurants.setVisible(false);
            viewListOrderHistory.setVisible(false);

            btnSelect.setVisible(false);
            btnCharge.setVisible(false);
            btnSearchFuck.setVisible(false);

            txtSearch.setVisible(false);
            txtCharge2.setVisible(false);

            /////////////////////////


        }
    }

    @FXML
    void showChargeAccountPressed(ActionEvent event) {              // Completed!!!
        if (lblChargeAmount.isVisible()){
            lblChargeAmount.setVisible(false);
        }
        else {
            btnConfirm.setVisible(false);
            viewListCarts.setVisible(false);

            lblChargeAmount.setVisible(true);

            viewListRestaurants.setVisible(false);
            viewListOrderHistory.setVisible(false);

            btnSelect.setVisible(false);
            btnCharge.setVisible(false);
            btnSearchFuck.setVisible(false);

            txtSearch.setVisible(false);
            txtCharge2.setVisible(false);

            lblChargeAmount.setText(String.valueOf(Customer.loggedInCustomer.getCharge()));
        }
    }

    @FXML
    void showRestaurantsPressed(ActionEvent event) {        // Completed!!!
        if (btnSelect.isVisible()){
            btnSelect.setVisible(false);
            btnSearchFuck.setVisible(false);
            viewListRestaurants.setVisible(false);
            txtSearch.setVisible(false);
        }
        else {
            viewListCarts.setVisible(false);

            lblChargeAmount.setVisible(false);

            viewListRestaurants.setVisible(true);
            viewListOrderHistory.setVisible(false);

            btnSelect.setVisible(true);
            btnCharge.setVisible(false);
            btnSearchFuck.setVisible(true);

            txtSearch.setVisible(true);
            txtCharge2.setVisible(false);

            viewListRestaurants.getItems().clear();
            viewListRestaurants.getItems().addAll(Restaurant.allRestaurants);
        }
    }

    @FXML
    void showOrderhistoryPressed(ActionEvent event) {                     //  Not Complete!!!
        if (viewListOrderHistory.isVisible()){
            viewListOrderHistory.setVisible(false);
        }
        else {
            btnConfirm.setVisible(false);
            viewListCarts.setVisible(false);

            lblChargeAmount.setVisible(false);

            viewListRestaurants.setVisible(false);
            viewListOrderHistory.setVisible(true);

            btnSelect.setVisible(false);
            btnCharge.setVisible(false);
            btnSearchFuck.setVisible(false);

            txtSearch.setVisible(false);
            txtCharge2.setVisible(false);
        }
    }

    @FXML
    void chargeAccountPressed(ActionEvent event) {    // Completed!!!
        if (btnCharge.isVisible()){
            lblChargeAmount.setVisible(false);
            btnCharge.setVisible(false);
            txtCharge2.setVisible(false);
        }
        else {
            btnConfirm.setVisible(false);
            viewListCarts.setVisible(false);

            lblChargeAmount.setVisible(true);
            lblChargeAmount.setText(String.valueOf(Customer.loggedInCustomer.getCharge()));

            viewListRestaurants.setVisible(false);
            viewListOrderHistory.setVisible(false);

            btnSelect.setVisible(false);
            btnCharge.setVisible(true);
            btnSearchFuck.setVisible(false);

            txtSearch.setVisible(false);
            txtCharge2.setVisible(true);
        }
    }

    @FXML
    void confirmPressed(ActionEvent event) {

    }

    @FXML
    void charge2Pressed(ActionEvent event) {                 // Completed!!!
        if (!txtCharge2.getText().equals("")){
            try {
                double charge = Double.parseDouble(txtCharge2.getText());
                Customer.loggedInCustomer.setCharge(charge);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Account charged successfully");
                alert.showAndWait();
                txtCharge2.setText("");
                lblChargeAmount.setText(String.valueOf(Customer.loggedInCustomer.getCharge()));
            }
            catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("invalid amount input!");
                alert.showAndWait();
                txtCharge2.setText("");
            }
        }
    }

    @FXML
    void selectPressed(ActionEvent event) throws IOException {                // Completed!!!
        int index = -1;
        for (int i = 0; i < viewListRestaurants.getItems().size(); i++) {
            if (viewListRestaurants.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            Customer.loggedInRestaurant = viewListRestaurants.getItems().get(index);
            System.out.println(Customer.loggedInRestaurant.getId());
            Stage stage = (Stage) btnBack1.getScene().getWindow();
            stage.close();
            AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("openSelectedRestaurant.fxml"));    //           Here we go next page
            Scene newScene = new Scene(anchorPane,950,630);
            stage.setScene(newScene);
            stage.show();
        }
    }

    public void fuckSearchPressed(ActionEvent event) {                   // Completed!!!
        if (!txtSearch.getText().equals("")){
            viewListRestaurants.getItems().clear();
            for (Restaurant item :
                    Restaurant.allRestaurants) {
                if (item.getName().equals(txtSearch.getText()))
                    viewListRestaurants.getItems().add(item);
            }
        }
        else {
            viewListRestaurants.getItems().clear();
            viewListRestaurants.getItems().addAll(Restaurant.allRestaurants);
        }
    }
}
