package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Admin;
import model.Customer;

import java.io.IOException;

public class SignUpViewController {

    @FXML
    private TextField txtPhone;

    @FXML
    private Button btnBack;

    @FXML
    private TextField txtUsername;

    @FXML
    private TextField txtAgainPassword;

    @FXML
    private TextField txtPassword;

    @FXML
    private Button btnResister;

    @FXML
    private RadioButton btnAdmin;

    @FXML
    private RadioButton btnCustomer;

    @FXML
    void RegisterPressed(ActionEvent event) throws IOException {
        if (btnAdmin.isSelected()&&btnCustomer.isSelected()){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setContentText("Choose one Admin/Customer");
            alert.showAndWait();
        }
        else if (txtUsername.getText().equals("")||txtPassword.getText().equals("")||txtAgainPassword.getText().equals("") || txtPhone.getText().equals("")){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setContentText("Enter username and password and phone number");
            alert.showAndWait();
        }
        else if (btnAdmin.isSelected()){   // signUp Admin
            String username,password,agan,phone;
            username = txtUsername.getText();
            password = txtPassword.getText();
            phone = txtPhone.getText();
            agan = txtAgainPassword.getText();
            if (!(this.checkAdminUsernameExist(username))){
                if (this.checkPasswordFormat(password,agan)){
                    new Admin(username,password,phone);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Warning");
                    alert.setContentText("register successfully");
                    alert.showAndWait();
                    Stage stage = (Stage) btnResister.getScene().getWindow();
                    stage.close();
                    AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));
                    Scene newScene = new Scene(anchorPane,1086,814);
                    stage.setScene(newScene);
                    stage.show();
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("incorrect password format or input password");
                    alert.showAndWait();
                }
            }
            else{
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("");
                alert.setContentText("Username already exist");
                alert.showAndWait();
            }
        }
        else if (btnCustomer.isSelected()){  // SignUp Customer
            String username,password,agan,phone;
            username = txtUsername.getText();
            password = txtPassword.getText();
            agan = txtAgainPassword.getText();
            phone = txtPhone.getText();
            if (!(this.checkCustomerUsernameExist(username))){
                if (this.checkPasswordFormat(password,agan)){
                    new Customer(username,password,phone);
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("");
                    alert.setContentText("register successfully");
                    alert.showAndWait();
                    Stage stage = (Stage) btnResister.getScene().getWindow();
                    stage.close();
                    AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));
                    Scene newScene = new Scene(anchorPane,1086,814);
                    stage.setScene(newScene);
                    stage.show();
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("incorrect password format or input password");
                    alert.showAndWait();
                }
            }
            else{
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("Username already exist");
                alert.showAndWait();
            }

        }
    }

    private boolean checkCustomerUsernameExist(String username) {
        for (Customer item :
                Customer.allCustomer) {
            if (item.getUsername().equals(username))
                return true;
        }
        return false;
    }

    private boolean checkPasswordFormat(String password, String again) {
        if (!password.equals(again))
        return false;
        return true;
    }

    private boolean checkAdminUsernameExist(String username) {
        for (Admin item :
                Admin.allAdmins) {
            if (item.getUsername().equals(username))
                return true;
        }
        return false;
    }

    @FXML
    void backPressed(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnResister.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Scene newScene = new Scene(anchorPane,1086,814);
        stage.setScene(newScene);
        stage.show();
    }

}
