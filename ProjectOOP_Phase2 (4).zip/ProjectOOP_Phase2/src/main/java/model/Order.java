package model;

import java.util.Random;

public class Order {

    private int orderId;
    private Food orderedFood = null;
    private Restaurant fromRestaurant = null;
    private Customer customer = null;
    int numOrder;
    private boolean status;
    private int originLocation,destinationLocation;

    public Order(int destinationLocation , Cart cart) {
        this.orderedFood = cart.getSelectedFood();
        this.fromRestaurant  =cart.getSelectedRestaurant();
        this.customer = Customer.loggedInCustomer;
        numOrder = cart.getNumOrder();
        status = false;
        originLocation = Customer.loggedInRestaurant.getLocation();
        this.destinationLocation = destinationLocation;
        //  make ID
        Random random = new Random();
        orderId = random.nextInt(100000);

        Customer.loggedInCustomer.buyProduct(orderedFood.getPrice()*numOrder);
        Customer.loggedInCustomer.getOrderHistory().add(this);
        Customer.loggedInFood.getOrders().add(this);  //    Test
        /*Restaurant restaurant = cart.getSelectedRestaurant();
        for (int i = 0; i < restaurant.getFoods().size(); i++) {
            if (Admin.loggedInRestaurant.getFoods().get(i).getClass().equals(Customer.loggedInFood.getClass()))
                Admin.loggedInFood = Admin.loggedInRestaurant.getFoods().get(i);
        }
        Admin.loggedInFood.getOpenOrders().add(this);

         */
    }

    public int getOrderId() {
        return orderId;
    }

    public Food getOrderedFood() {
        return orderedFood;
    }

    public void setOrderedFood(Food orderedFood) {
        this.orderedFood = orderedFood;
    }

    public Restaurant getFromRestaurant() {
        return fromRestaurant;
    }

    public void setFromRestaurant(Restaurant fromRestaurant) {
        this.fromRestaurant = fromRestaurant;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public int getNumOrder() {
        return numOrder;
    }

    public void setNumOrder(int numOrder) {
        this.numOrder = numOrder;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getOriginLocation() {
        return originLocation;
    }

    public void setOriginLocation(int originLocation) {
        this.originLocation = originLocation;
    }

    public int getDestinationLocation() {
        return destinationLocation;
    }

    public void setDestinationLocation(int destinationLocation) {
        this.destinationLocation = destinationLocation;
    }

    @Override
    public String toString() {
        return "Food name: "+orderedFood.getFoodName()+
                "  from restaurant: " +fromRestaurant.getName()+
                "  with price: "+ orderedFood.getPrice()+
                "  Number: "+numOrder+
                "  Status:  "+status;
    }
}
