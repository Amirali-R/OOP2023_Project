package model;

public class Cart {

    private Food selectedFood = null;
    private Restaurant selectedRestaurant = null;
    private int numOrder;

    public Cart(int numOrder) {
        this.numOrder = numOrder;
        this.selectedFood = Customer.loggedInFood;
        this.selectedRestaurant = Customer.loggedInRestaurant;
    }

    public Food getSelectedFood() {
        return selectedFood;
    }

    public void setSelectedFood(Food selectedFood) {
        this.selectedFood = selectedFood;
    }

    public Restaurant getSelectedRestaurant() {
        return selectedRestaurant;
    }

    public void setSelectedRestaurant(Restaurant selectedRestaurant) {
        this.selectedRestaurant = selectedRestaurant;
    }

    public int getNumOrder() {
        return numOrder;
    }

    public void setNumOrder(int numOrder) {
        this.numOrder = numOrder;
    }

    @Override
    public String toString() {
        return "Food name: "+selectedFood.getFoodName()+"  from restaurant: "+selectedRestaurant.getName()+"  with price: "+selectedFood.getPrice()+"Number: "+numOrder;
    }
}
