package model;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

public class Food {
    private String foodName;
    private String foodType;
    private double price;
    private String foodID;
    private String buyerID;
    private int totalRate;

    private ArrayList<Order> openOrders = new ArrayList<>();
    public ArrayList<CommentFood> comments;
    public ArrayList<Order> orders = new ArrayList<>();
    public ArrayList<HashMap> foodsRating;

    private int discount;
    private int timeStop = 0;
    private boolean isActive;


    public Food(String foodName, String foodType, int price, String buyerID) {
        this.foodName = foodName;
        this.foodType = foodType;
        this.price = price;
        this.buyerID = buyerID;
        Random random = new Random();
        this.foodID = String.valueOf(random.nextInt(100000)+String.valueOf(random.nextInt(10000)));
        this.discount = 0;
        this.isActive = true;
        this.comments = new ArrayList<>();
    }

    public ArrayList<Order> getOpenOrders() {
        return openOrders;
    }

    public void setOpenOrders(ArrayList<Order> openOrders) {
        this.openOrders = openOrders;
    }

    public int getTimeStop() {
        return timeStop;
    }

    public void setTimeStop(int timeStop) {
        this.timeStop = timeStop;
    }

    public String getFoodID() {
        return foodID;
    }

    public String getBuyerID() {
        return buyerID;
    }

    public void setBuyerID(String buyerID) {
        this.buyerID = buyerID;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodType() {
        return foodType;
    }

    public void setFoodType(String foodType) {
        this.foodType = foodType;
    }

    public double getPrice() {
        double ret = price * (1 - this.discount / 100);
        return ret;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getTotalRate() {
        int total = 0;
        for (CommentFood item :
                this.comments) {
            total += item.getRating();
        }
        return total;
    }

    public void setTotalRate(int totalRate) {
        this.totalRate = totalRate;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public ArrayList<CommentFood> getComments() {
        return comments;
    }

    public ArrayList<Order> getOrders() {
        return orders;
    }

    @Override
    public String toString() {
        return "Name: "+getFoodName()+"   FoodType: "+getFoodType()+"   FoodID: "+getFoodID()+"   Price: "+String.valueOf(getPrice())+"   Discount: "+String.valueOf(getDiscount())+"   IsActive: "+isActive();
    }
}
