package model;

public class User {
    String name,id,foodstring;

    public User(String name, String id, String foodstring) {
        this.name = name;
        this.id = id;
        this.foodstring = foodstring;
    }
}
