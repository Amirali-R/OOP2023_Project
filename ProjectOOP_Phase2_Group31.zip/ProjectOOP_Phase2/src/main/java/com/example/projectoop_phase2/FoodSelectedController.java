package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Cart;
import model.CommentFood;
import model.Customer;
import java.io.IOException;

public class FoodSelectedController {

    @FXML
    private ListView<String> viewListRatings;

    @FXML
    private Label lblNum;
    
    @FXML
    private Button btnBack;

    @FXML
    private TextField txtAddComment;

    @FXML
    private Label lblShow;

    @FXML
    private ListView<CommentFood> viewListComments;

    @FXML
    private TextField txtAddRating;

    @FXML
    private TextField txtNewRating;

    @FXML
    private AnchorPane anchorPaneShowRating;

    @FXML
    private AnchorPane anchorPaneComments;

    @FXML
    private TextField txtNewComment;

    @FXML
    void backPressed(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("openSelectedRestaurant.fxml"));    //           Here we go next page
        Scene newScene = new Scene(anchorPane,950,630);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void showCommentsPressed(ActionEvent event) {
        if (anchorPaneComments.isVisible())
            anchorPaneComments.setVisible(false);
        else {
            anchorPaneComments.setVisible(true);
            viewListComments.getItems().clear();
            viewListComments.getItems().addAll(Customer.loggedInFood.getComments());
        }
        anchorPaneShowRating.setVisible(false);
    }

    @FXML
    void addCartPressed(ActionEvent event) {
        if (Customer.loggedInFood.isActive()){
            if (!this.checkCart()) {
                if (!lblNum.getText().equals("0")){
                    int numOrder = Integer.parseInt(lblNum.getText());
                    Customer.loggedInCustomer.getCarts().add(new Cart(numOrder));
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setContentText("Food added to cart");
                    alert.showAndWait();
                    lblNum.setText("0");
                }
            }
            else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("Food is added before!");
                alert.showAndWait();
            }
            
        }
        else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setContentText("Food is not Active now");
            alert.showAndWait();
        }
    }

    private boolean checkCart() {
        for (Cart item :
                Customer.loggedInCustomer.getCarts()) {
            if (item.getSelectedFood().getFoodID().equals(Customer.loggedInFood.getFoodID()))
                return true;
        }
        return false;
    }

    @FXML
    void showRatingPressed(ActionEvent event) {
        if (anchorPaneShowRating.isVisible())
            anchorPaneShowRating.setVisible(false);
        else {
            anchorPaneShowRating.setVisible(true);
            viewListRatings.getItems().clear();
            for (CommentFood item :
                    Customer.loggedInFood.getComments()) {
                viewListRatings.getItems().add("User ID:  "+item.getUserID()+"  Rating :"+item.getRating());
            }
        }
        anchorPaneComments.setVisible(false);
    }

    @FXML
    void addCommentPressed(ActionEvent event) {
        if (!txtAddComment.getText().equals("")&&!txtAddRating.getText().equals("")){
            try {
                int rating = Integer.parseInt(txtAddRating.getText());
                new CommentFood(txtAddComment.getText(),rating,Customer.loggedInCustomer.getUserID(),false);
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("Commented successfully");
                alert.showAndWait();
                txtAddRating.setText("");
                txtAddComment.setText("");
                viewListComments.getItems().clear();
                viewListComments.getItems().addAll(Customer.loggedInFood.getComments());
            }
            catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("invalid Rating");
                alert.showAndWait();
                txtAddRating.setText("");
            }
        }
    }

    @FXML
    void editCommentPressed(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < viewListComments.getItems().size(); i++) {
            if (viewListComments.getSelectionModel().isSelected(i))
                index = i;
        }
        if (index!=-1 &&(!txtNewRating.equals("")||!txtNewComment.equals(""))){
            if (this.checkCommentId(viewListComments.getItems().get(index))) {
                if (txtNewRating.equals("")) {
                    Customer.loggedInFood.getComments().get(index).setTxt(txtNewComment.getText());
                    viewListComments.getItems().clear();
                    viewListComments.getItems().addAll(Customer.loggedInFood.getComments());
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setContentText("text Edited successfully");
                    alert.showAndWait();
                    txtNewComment.setText("");
                } else if (txtNewComment.equals("")) {
                    try {
                        int rating = Integer.parseInt(txtNewRating.getText());
                        Customer.loggedInFood.getComments().get(index).setRating(rating);
                        viewListComments.getItems().clear();
                        viewListComments.getItems().addAll(Customer.loggedInFood.getComments());
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information");
                        alert.setContentText("Rating Edited successfully");
                        alert.showAndWait();
                        txtNewRating.setText("");
                    } catch (NumberFormatException e) {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Warning");
                        alert.setContentText("invalid Rating");
                        alert.showAndWait();
                        txtAddRating.setText("");
                    }
                } else {
                    try {
                        int rating = Integer.parseInt(txtNewRating.getText());
                        Customer.loggedInFood.getComments().get(index).setRating(rating);
                        Customer.loggedInFood.getComments().get(index).setTxt(txtNewComment.getText());
                        viewListComments.getItems().clear();
                        viewListComments.getItems().addAll(Customer.loggedInFood.getComments());
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Information");
                        alert.setContentText("Comment Edited successfully");
                        alert.showAndWait();
                        txtNewRating.setText("");
                    } catch (NumberFormatException e) {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Warning");
                        alert.setContentText("invalid Rating");
                        alert.showAndWait();
                        txtAddRating.setText("");
                    }
                }
            }
            else{
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("you can't edit this comment\nIt isn't yours!");
                    alert.showAndWait();
                    txtNewComment.setText("");
                    txtNewRating.setText("");
                }
        }
    }

    private boolean checkCommentId(CommentFood commentFood) {
        if (commentFood.getUserID().equals(Customer.loggedInCustomer.getUserID()))
            return true;
        return false;
    }

    public void showFoodName(MouseEvent mouseEvent) {
        lblShow.setText(Customer.loggedInFood.getFoodName());
    }

    public void minesNum(ActionEvent event) {
        int num = Integer.parseInt(lblNum.getText());
        if (num != 0)
           num--;
        lblNum.setText(String.valueOf(num));
    }

    public void plusNum(ActionEvent event) {
        int num = Integer.parseInt(lblNum.getText());
        num++;
        lblNum.setText(String.valueOf(num));
    }
}
