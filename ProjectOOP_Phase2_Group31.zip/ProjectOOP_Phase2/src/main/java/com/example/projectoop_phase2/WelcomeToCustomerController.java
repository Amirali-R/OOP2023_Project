package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Cart;
import model.Customer;
import model.Order;
import model.Restaurant;

import java.io.IOException;

public class WelcomeToCustomerController {

    @FXML
    private Button btnBack;

    @FXML
    private AnchorPane anchorPaneShowOrderHistory;

    @FXML
    private Label lblChargeAmount;

    @FXML
    private ListView<Restaurant> viewListRestaurants;

    @FXML
    private ListView<Order> listViewOrders;

    @FXML
    private AnchorPane anchorPaneShowRestairants;

    @FXML
    private ListView<Cart> viewListCarts;

    @FXML
    private AnchorPane anchorPaneEditCart;

    @FXML
    private AnchorPane anchorPaneShowCarts;

    @FXML
    private Label lblShowNum;

    @FXML
    private AnchorPane anchorPaneCharge;

    @FXML
    private TextField txtAddCharge;

    @FXML
    private TextField txtSearch;



    @FXML
    void backPressed(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));    //           Here we go back
        Scene newScene = new Scene(anchorPane,1086,738);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void showAddCharge(ActionEvent event)  {
        if (anchorPaneCharge.isVisible())
            anchorPaneCharge.setVisible(false);
        else
            anchorPaneCharge.setVisible(true);
        anchorPaneEditCart.setVisible(false);
        anchorPaneShowCarts.setVisible(false);
        anchorPaneShowOrderHistory.setVisible(false);
        anchorPaneShowRestairants.setVisible(false);
    }

    @FXML
    void showRestaurants(ActionEvent event) {
        if (anchorPaneShowRestairants.isVisible())
            anchorPaneShowRestairants.setVisible(false);
        else {
            anchorPaneShowRestairants.setVisible(true);
            viewListRestaurants.getItems().clear();
            viewListRestaurants.getItems().addAll(Restaurant.allRestaurants);
        }
        anchorPaneCharge.setVisible(false);
        anchorPaneEditCart.setVisible(false);
        anchorPaneShowCarts.setVisible(false);
        anchorPaneShowOrderHistory.setVisible(false);
    }

    @FXML
    void showCartStatus(ActionEvent event) {
        if (anchorPaneShowCarts.isVisible())
            anchorPaneShowCarts.setVisible(false);
        else {
            anchorPaneShowCarts.setVisible(true);
            viewListCarts.getItems().clear();
            viewListCarts.getItems().addAll(Customer.loggedInCustomer.getCarts());
        }
        anchorPaneCharge.setVisible(false);
        anchorPaneShowOrderHistory.setVisible(false);
        anchorPaneEditCart.setVisible(false);
        anchorPaneShowRestairants.setVisible(false);
    }

    @FXML
    void showOrderhistory(ActionEvent event) {
        if (anchorPaneShowOrderHistory.isVisible())
            anchorPaneShowOrderHistory.setVisible(false);
        else {
            listViewOrders.getItems().clear();
            listViewOrders.getItems().addAll(Customer.loggedInCustomer.getOrderHistory());
            anchorPaneShowOrderHistory.setVisible(true);
        }
        anchorPaneCharge.setVisible(false);
        anchorPaneShowRestairants.setVisible(false);
        anchorPaneEditCart.setVisible(false);
        anchorPaneShowCarts.setVisible(false);
    }


    @FXML
    void chargeAccount(ActionEvent event) {
        if (!txtAddCharge.getText().equals("")){
            try {
                int amount = Integer.parseInt(txtAddCharge.getText());
                Customer.loggedInCustomer.setCharge(amount);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Account charged successfully");
                alert.showAndWait();
                lblChargeAmount.setText("Amount:  "+ String.valueOf(Customer.loggedInCustomer.getCharge()));
                txtAddCharge.setText("");
            }
            catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Waning");
                alert.setContentText("Invalid amount");
                alert.showAndWait();
            }
        }
    }

    @FXML
    void selecRestaurantPressed(ActionEvent event) throws IOException {
        int index = -1;
        for (int i = 0; i < viewListRestaurants.getItems().size(); i++) {
            if (viewListRestaurants.getSelectionModel().isSelected(i))
                index = i;
        }
        if (index !=-1){
            Customer.loggedInRestaurant = viewListRestaurants.getItems().get(index);
            Stage stage = (Stage) btnBack.getScene().getWindow();
            stage.close();
            AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("openSelectedRestaurant.fxml"));    //           Here we go next page
            Scene newScene = new Scene(anchorPane,950,630);
            stage.setScene(newScene);
            stage.show();
        }
    }

    @FXML
    void ConfirmCartPressed(ActionEvent event) {                   //   Not completed
        int index = -1;
        for (int i = 0; i < viewListCarts.getItems().size(); i++) {
            if (viewListCarts.getSelectionModel().isSelected(i))
                index = i;
        }

        if (index!=-1){
            Cart item = viewListCarts.getItems().get(index);
            if (Customer.loggedInCustomer.getCharge()<item.getSelectedFood().getPrice()){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Waning");
                alert.setContentText("you have not enough charge to buy this item");
                alert.showAndWait();
            }
            else {
                //    !!!!!!!!!!!!!!!!!!         input destination


                ////////////////////////

                new Order(100,item);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Thanks for your choice\n"+Customer.loggedInRestaurant.getName());
                alert.showAndWait();

                Customer.loggedInCustomer.getCarts().remove(item);
                viewListCarts.getItems().clear();
                viewListCarts.getItems().addAll(Customer.loggedInCustomer.getCarts());
            }
        }
    }

    @FXML
    void editCartPressed(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < Customer.loggedInCustomer.getCarts().size(); i++) {
            if (viewListCarts.getSelectionModel().isSelected(i))
                index = i;
        }
        if (index!=-1) {
            Cart item = viewListCarts.getItems().get(index);
            anchorPaneEditCart.setVisible(true);
            lblShowNum.setText(String.valueOf(item.getNumOrder()));
            anchorPaneCharge.setVisible(false);
            anchorPaneShowCarts.setVisible(false);
            anchorPaneShowRestairants.setVisible(false);
            anchorPaneShowOrderHistory.setVisible(false);
        }
    }

    @FXML
    void minesPressed(ActionEvent event) {
        int num = Integer.parseInt(lblShowNum.getText());
        if (num != 1){
            num--;
            lblShowNum.setText(String.valueOf(num));
        }
    }

    @FXML
    void plusPressed(ActionEvent event) {
        int num = Integer.parseInt(lblShowNum.getText());
        num++;
        lblShowNum.setText(String.valueOf(num));
    }

    @FXML
    void editCart2(ActionEvent event) {
        int index = viewListCarts.getSelectionModel().getSelectedIndex();
        Customer.loggedInCustomer.getCarts().get(index).setNumOrder(Integer.parseInt(lblShowNum.getText()));
        viewListCarts.getItems().clear();
        viewListCarts.getItems().addAll(Customer.loggedInCustomer.getCarts());
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setContentText("Cart  edited successfully");
        alert.showAndWait();
        anchorPaneEditCart.setVisible(false);
        anchorPaneShowCarts.setVisible(true);
    }

    public void backToShowCarts(ActionEvent event) {
        anchorPaneEditCart.setVisible(false);
        anchorPaneShowCarts.setVisible(true);
    }

    public void showLblCgarge(MouseEvent mouseEvent) {
        lblChargeAmount.setText("Amount:  "+String.valueOf(Customer.loggedInCustomer.getCharge()));
    }

    public void searchPressed(ActionEvent event) {
        if (txtSearch.getText().equals("")){
            viewListRestaurants.getItems().clear();
            viewListRestaurants.getItems().addAll(Restaurant.allRestaurants);
        }
        else {
            viewListRestaurants.getItems().clear();
            for (Restaurant item :
                    Restaurant.allRestaurants) {
                if (item.getName().equals(txtSearch.getText()))
                    viewListRestaurants.getItems().add(item);
            }
        }
    }
}
