package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;

public class OpenAdminsFoodMenuController {

    @FXML
    private ListView<CommentFood> viewList;

    @FXML
    private ListView<String> viewListRating;

    @FXML
    private ListView<Order> viewListOrders;


    @FXML
    private Button btnAddFake;

    @FXML
    private Button btnBack1;

    @FXML
    private Button btnAddResponse;

    @FXML
    private TextField txtAddresponse;

    @FXML
    void back1Pressed(ActionEvent event) throws IOException {
        viewList.setVisible(false);
        viewListOrders.setVisible(false);
        viewListRating.setVisible(false);
        Stage stage = (Stage) btnBack1.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("OpenAdminsMenu.fxml"));    //           Here we go back
        Scene newScene = new Scene(anchorPane,950,630);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void DisplayRatings(ActionEvent event) {     //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        if (viewListRating.isVisible()){
            viewListRating.setVisible(false);
            btnAddResponse.setVisible(false);
            txtAddresponse.setVisible(false);
        }
        else {
            viewListRating.setVisible(true);
            btnAddResponse.setVisible(false);
            txtAddresponse.setVisible(false);
            viewListRating.getItems().clear();
            for (CommentFood item :
                    Admin.loggedInFood.getComments()) {
                viewListRating.getItems().add("User  "+item.getUserID()+"  rated:  "+String.valueOf(item.getRating()));
            }
        }
        viewList.setVisible(false);
        viewListOrders.setVisible(false);
    }

    @FXML
    void displayOpenOrders(ActionEvent event) {
        if (viewListOrders.isVisible()){
            viewListOrders.setVisible(false);
            btnAddResponse.setVisible(false);
            txtAddresponse.setVisible(false);
        }
        else {
            viewListOrders.setVisible(true);
            btnAddResponse.setVisible(false);
            txtAddresponse.setVisible(false);
            viewListOrders.getItems().clear();
            viewListOrders.getItems().addAll(Admin.loggedInFood.getOrders());
        }
        viewList.setVisible(false);
        viewListRating.setVisible(false);
    }

    @FXML
    void sendOrder(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < viewListOrders.getItems().size(); i++) {
            if (viewListOrders.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            Customer customer = viewListOrders.getItems().get(index).getCustomer();
            System.out.println(customer.getUserID());  // Test
            int index2 = -1;
            for (int i = 0; i < customer.getOrderHistory().size(); i++) {
                if (customer.getOrderHistory().get(i).getClass().equals(viewListOrders.getItems().get(index).getClass()))
                    index2 = i;
            }
            if (index2!=-1){
                customer.getOrderHistory().get(index2).setStatus(true);
                Admin.loggedInFood.getOrders().remove(index);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Order send successfully");
                alert.showAndWait();
            }
        }
    }

    @FXML
    void displayComments(ActionEvent event) {
        if (viewList.isVisible()){
            viewListRating.setVisible(false);
            viewList.setVisible(false);
            btnAddResponse.setVisible(false);
            txtAddresponse.setVisible(false);
            viewListOrders.setVisible(false);
            btnAddFake.setVisible(false);
        }
        else {
            viewList.setVisible(true);
            btnAddResponse.setVisible(true);
            txtAddresponse.setVisible(true);
            btnAddFake.setVisible(true);
            txtAddresponse.setText("");
            viewList.getItems().clear();
            viewList.getItems().addAll(Admin.loggedInFood.getComments());
            viewListOrders.setVisible(false);
            viewListRating.setVisible(false);
        }
    }

    @FXML
    void addResponsePressed(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < viewList.getItems().size(); i++) {
            if (viewList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            if (!txtAddresponse.getText().equals("")){
                Admin.loggedInFood.getComments().get(index).setResponse(txtAddresponse.getText());
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Response added successfully");
                alert.showAndWait();
                viewList.getItems().clear();
                viewList.getItems().addAll(Admin.loggedInFood.getComments());
            }
        }
    }

    public void addComment(ActionEvent event) {
        if (!txtAddresponse.getText().equals("")){
            new CommentFood(txtAddresponse.getText(),10,Admin.loggedInAdmin.getUserID(),true);
            viewList.getItems().clear();
            viewList.getItems().addAll(Admin.loggedInFood.getComments());
        }
    }
}
