package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Admin;
import model.Customer;

import java.io.IOException;
import java.util.Random;

public class ForgetPasswordController {

    @FXML
    private TextField txtUsername;

    @FXML
    private TextField txtPhonenumber;

    @FXML
    private TextField txtCode;

    @FXML
    private TextField txtNewPassword;

    @FXML
    private RadioButton btnAdmin;

    @FXML
    private RadioButton btnCustomer;

    private String captcha = "";

    @FXML
    void sendPressed(ActionEvent event) {
        if (!txtUsername.getText().equals("") && !txtPhonenumber.getText().equals("")){
            if (btnAdmin.isSelected()&&btnCustomer.isSelected()){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("Enter one item Admin/Customer");
                alert.showAndWait();
            }
            else if (btnAdmin.isSelected()){
                if (this.checkAdminUsernameExist(txtUsername.getText())){
                    Admin admin = this.getAdmin(txtUsername.getText());
                    if (admin!=null&&admin.getPhone().equals(txtPhonenumber.getText())){
                        captcha = this.createCaptcha();
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Message");
                        alert.setContentText("Here is your recovery code:  " + captcha);
                        alert.showAndWait();
                    }

                }
                else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("Username doesn't exist!");
                    alert.showAndWait();
                }
            }
            else if (btnCustomer.isSelected()){    // not completed
                if (this.checkCustomerUsernameExist(txtUsername.getText())){
                    Customer customer = this.getCustomer(txtUsername.getText());
                    if (customer != null && customer.getPhone().equals(txtPhonenumber.getText())){
                        captcha = this.createCaptcha();
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Message");
                        alert.setContentText("Here is your recovery code:  " + captcha);
                        alert.showAndWait();
                    }
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("Username doesn't exist!");
                    alert.showAndWait();
                }
            }
        }
        else {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setContentText("Enter Username");
            alert.showAndWait();
        }
    }

    private Customer getCustomer(String user) {
        for (Customer item :
                Customer.allCustomer) {
            if (item.getUsername().equals(user))
                return item;
        }
        return null;
    }

    private Admin getAdmin(String username) {
        for (Admin item :
                Admin.allAdmins) {
            if (item.getUsername().equals(username))
                return item;
        }
        return null;
    }

    private String createCaptcha() {
        char data[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
        char index[] = new char[7];

        Random r = new Random();
        int i = 0;

        for (i = 0; i < (index.length); i++) {
            int ran = r.nextInt(data.length);
            index[i] = data[ran];
        }
        captcha = String.valueOf(index);
        return String.valueOf(index);
    }

    @FXML
    void changePasswordPressed(ActionEvent event) throws IOException {
        if (!txtCode.getText().equals("") && !txtNewPassword.getText().equals("")){
            if (btnCustomer.isSelected()&& !btnAdmin.isSelected()){
                if (captcha.equals("")){
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("recovery code hasn't been send");
                    alert.showAndWait();
                }
                else {
                    if (txtCode.getText().equals(captcha)){
                        Customer customer = this.getCustomer(txtUsername.getText());
                        customer.setPassword(txtNewPassword.getText());
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Message");
                        alert.setContentText("password changed successfully");
                        alert.showAndWait();
                        txtCode.setText("");
                        txtNewPassword.setText("");
                        txtPhonenumber.setText("");
                        txtUsername.setText("");
                        Stage stage = (Stage) btnCustomer.getScene().getWindow();
                        stage.close();
                        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));
                        Scene newScene = new Scene(anchorPane,1086,738);
                        stage.setScene(newScene);
                        stage.show();
                    }
                    else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Warning");
                        alert.setContentText("wrong code");
                        alert.showAndWait();
                    }
                }
            }
            else if (btnAdmin.isSelected() && !btnCustomer.isSelected()){
                if (captcha.equals("")){
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("recovery code hasn't been send");
                    alert.showAndWait();
                }
                else {
                    if (txtCode.getText().equals(captcha)){
                        Admin admin = this.getAdmin(txtUsername.getText());
                        admin.setPassword(txtNewPassword.getText());
                        Alert alert = new Alert(Alert.AlertType.INFORMATION);
                        alert.setTitle("Message");
                        alert.setContentText("password changed successfully");
                        alert.showAndWait();
                        txtCode.setText("");
                        txtNewPassword.setText("");
                        txtPhonenumber.setText("");
                        txtUsername.setText("");
                        Stage stage = (Stage) btnCustomer.getScene().getWindow();
                        stage.close();
                        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));
                        Scene newScene = new Scene(anchorPane,1086,738);
                        stage.setScene(newScene);
                        stage.show();
                    }
                    else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Warning");
                        alert.setContentText("wrong code");
                        alert.showAndWait();
                    }
                }
            }
        }
        else {

        }
    }

    @FXML
    void backPressed(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnCustomer.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Scene newScene = new Scene(anchorPane,1086,738);
        stage.setScene(newScene);
        stage.show();
    }

    private boolean checkCustomerUsernameExist(String username) {
        for (Customer item :
                Customer.allCustomer) {
            if (item.getUsername().equals(username))
                return true;
        }
        return false;
    }

    private boolean checkPasswordFormat(String password) {   //        Not completed!!!
        return true;
    }

    private boolean checkAdminUsernameExist(String username) {
        for (Admin item :
                Admin.allAdmins) {
            if (item.getUsername().equals(username))
                return true;
        }
        return false;
    }

}
