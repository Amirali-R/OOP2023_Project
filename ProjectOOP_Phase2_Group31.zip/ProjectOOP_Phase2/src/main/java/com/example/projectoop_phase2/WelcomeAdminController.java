package com.example.projectoop_phase2;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Admin;
import model.Restaurant;
import model.User;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WelcomeAdminController {

    @FXML
    private Button btnBack;

    @FXML
    private Button btnOpenRestaurant;

    @FXML
    private AnchorPane anchorPaneShow;

    @FXML
    private AnchorPane anchorPane1;

    @FXML
    private Button btnSearch;

    @FXML
    private ListView<Restaurant> list;

    @FXML
    private Label lblShow;

    @FXML
    private Button btnShowRestauranrs;

    @FXML
    private Button btnAddRestaurant;

    @FXML
    private TextField txtSearch;

    @FXML
    private Label lbladdRestaurant;

    @FXML
    private Button btnConfirmAdd;

    @FXML
    private TextField txtType1;

    @FXML
    private TextField txtType2;

    @FXML
    private TextField txtType3;

    @FXML
    private TextField txtType4;

    @FXML
    private TextField txtType5;

    @FXML
    private TextField txtType7;

    @FXML
    private TextField txtAddName;

    @FXML
    private TextField txtLocation;

    @FXML
    private AnchorPane anchorPaneAddRestaurant;

    @FXML
    void backToLast2(ActionEvent event) {
        anchorPaneAddRestaurant.setVisible(false);
        anchorPane1.setVisible(true);
    }

    @FXML
    void ConfirmAdd(ActionEvent event) {
        lbladdRestaurant.setText("");
        if ((txtType1.getText().equals("")&&txtType2.getText().equals("")&&txtType3.getText().equals("")&&txtType4.getText().equals("")&&txtType5.getText().equals("")&&txtType7.getText().equals(""))||txtAddName.equals("")||txtLocation.equals(""))
            lbladdRestaurant.setText("fill all the texts");
        else {
            lbladdRestaurant.setText("");
            try {
                int location = Integer.parseInt(txtLocation.getText());
                ArrayList<String> types  =new ArrayList<>();

                if (!txtType1.getText().equals(""))
                    types.add(txtType1.getText());

                if (!txtType2.getText().equals(""))
                    types.add(txtType2.getText());

                if (!txtType3.getText().equals(""))
                    types.add(txtType3.getText());

                if (!txtType4.getText().equals(""))
                    types.add(txtType4.getText());

                if (!txtType5.getText().equals(""))
                    types.add(txtType5.getText());

                if (!txtType7.getText().equals(""))
                    types.add(txtType7.getText());

                new Restaurant(txtAddName.getText(),types,location);
                list.getItems().clear();
                list.getItems().addAll(Admin.loggedInAdmin.adminsRestaurants);

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Restaurant added successfully");
                alert.showAndWait();
            }
            catch (NumberFormatException e){
                lbladdRestaurant.setText("invalid location");
            }
            /*
            Pattern pattern = Pattern.compile("\\d+");
            Matcher matcher = pattern.matcher(txtLocation.getText());
            if (matcher.find()){
                int location = Integer.parseInt(txtLocation.getText());
                ArrayList<String> types  =new ArrayList<>();

                if (!txtType1.getText().equals(""))
                    types.add(txtType1.getText());

                if (!txtType2.getText().equals(""))
                    types.add(txtType2.getText());

                if (!txtType3.getText().equals(""))
                    types.add(txtType3.getText());

                if (!txtType4.getText().equals(""))
                    types.add(txtType4.getText());

                if (!txtType5.getText().equals(""))
                    types.add(txtType5.getText());

                if (!txtType7.getText().equals(""))
                    types.add(txtType7.getText());

                //Admin.loggedInAdmin.adminsRestaurants.add(new Restaurant(txtAddName.getText(),types,location));
                new Restaurant(txtAddName.getText(),types,location);
                list.getItems().clear();
                list.getItems().addAll(Admin.loggedInAdmin.showList());

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Restaurant added successfully");
                alert.showAndWait();

                anchorPaneAddRestaurant.setVisible(false);
                anchorPane1.setVisible(true);
            }
            else
                lbladdRestaurant.setText("invalid location");

             */
        }
    }

    @FXML
    void backPressed(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("hello-view.fxml"));
        Scene newScene = new Scene(anchorPane,1086,814);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void addRestaurantpressed(ActionEvent event) {
        anchorPane1.setVisible(false);
        anchorPaneAddRestaurant.setVisible(true);

        txtType1.setText("");
        txtType2.setText("");
        txtType3.setText("");
        txtType4.setText("");
        txtType5.setText("");
        txtType7.setText("");
        txtAddName.setText("");
        txtLocation.setText("");
    }

    @FXML
    void showRestaurantsPress(ActionEvent event) {
        anchorPane1.setVisible(false);
        anchorPaneShow.setVisible(true);

        txtSearch.setText("");

        list.getItems().clear();
        //list.refresh();
        list.getItems().addAll(Admin.loggedInAdmin.adminsRestaurants);
    }

    @FXML
    void backTolast(ActionEvent event) {
        anchorPane1.setVisible(true);
        anchorPaneShow.setVisible(false);
    }

    @FXML
    void searchPressed(ActionEvent event) {
        if (txtSearch.getText().equals("")){
            lblShow.setText("");
            list.getItems().clear();
            list.getItems().addAll(Admin.loggedInAdmin.adminsRestaurants);
        }
        else if (this.checkRestaurantexist(txtSearch.getText())){
            //lblShow.setText("");
            list.getItems().clear();

            for (Restaurant item :
                    Admin.loggedInAdmin.adminsRestaurants) {
                if (item.getName().equals(txtSearch.getText()))
                    list.getItems().add(item);
            }
        }
        else {
            list.getItems().clear();
            lblShow.setText("No restaurant exist with the given name");
            list.getItems().addAll(Admin.loggedInAdmin.adminsRestaurants);
        }
    }

    private boolean checkRestaurantexist(String name) {
        for (Restaurant item :
                Admin.loggedInAdmin.adminsRestaurants) {
            if (item.getName().equals(name))
                return true;
        }
        return false;
    }

    @FXML
    void openRestaurantPressed(ActionEvent event) throws IOException {
        boolean selectItem = false;
        int index = -1;
        for (int i = 0; i < list.getItems().size(); i++) {
            if (list.getSelectionModel().isSelected(i)) {
                selectItem = true;
                index = i;
            }
        }
        System.out.println(index);  // Test
        if (index !=-1){
            Admin.loggedInRestaurant = list.getItems().get(index);
            Stage stage = (Stage) btnOpenRestaurant.getScene().getWindow();
            stage.close();
            AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("OpenAdminsRestaurant.fxml"));    //           Here we go
            Scene newScene = new Scene(anchorPane,950,630);
            stage.setScene(newScene);
            stage.show();
        }
    }
}
