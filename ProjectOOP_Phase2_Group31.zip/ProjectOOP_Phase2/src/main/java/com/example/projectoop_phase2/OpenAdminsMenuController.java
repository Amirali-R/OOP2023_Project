package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Admin;
import model.Food;

import java.io.IOException;

public class OpenAdminsMenuController {

    @FXML
    private TextField txtFoodType;

    @FXML
    private ListView<Food> foodsList;

    @FXML
    private Button btnBack1;

    @FXML
    private TextField txtName;

    @FXML
    private Button btnBack2;

    @FXML
    private TextField txtTimeStop;

    @FXML
    private AnchorPane anchorPane1;

    @FXML
    private AnchorPane anchorPane2;

    @FXML
    private TextField txtNewName;

    @FXML
    private TextField txtNewPrice;

    @FXML
    private TextField txtDiscountPercent;

    @FXML
    private TextField txtPrice;

    @FXML
    private Label lblShowDetails;

    @FXML
    void back1Pressed(ActionEvent event) throws IOException {
        foodsList.setVisible(false);
        Stage stage = (Stage) btnBack1.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("OpenAdminsRestaurant.fxml"));    //           Here we go back
        Scene newScene = new Scene(anchorPane,950,630);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void selectPressed(ActionEvent event) throws IOException {
        int index = -1;
        for (int i = 0; i < foodsList.getItems().size(); i++) {
            if (foodsList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            Admin.loggedInFood = Admin.loggedInRestaurant.getFoods().get(index);
            Stage stage = (Stage) btnBack1.getScene().getWindow();
            stage.close();
            AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("openAdminsFoodMenu.fxml"));    //           Here we go next page
            Scene newScene = new Scene(anchorPane,950,630);
            stage.setScene(newScene);
            stage.show();
        }
    }

    @FXML
    void deletePressed(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < foodsList.getItems().size(); i++) {
            if (foodsList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index != -1){
            Admin.loggedInRestaurant.getFoods().remove(index);
            foodsList.getItems().clear();
            foodsList.getItems().addAll(Admin.loggedInRestaurant.getFoods());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Food Deleted Successfully");
            alert.showAndWait();
        }
    }

    @FXML
    void activeFoodPressed(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < foodsList.getItems().size(); i++) {
            if (foodsList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            if (Admin.loggedInRestaurant.getFoods().get(index).isActive()){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Food  is already Activated");
                alert.showAndWait();
            }
            else {
                Admin.loggedInRestaurant.getFoods().get(index).setActive(true);
                foodsList.getItems().clear();
                foodsList.getItems().addAll(Admin.loggedInRestaurant.getFoods());
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Food Activated Successfully");
                alert.showAndWait();
            }
        }
    }

    @FXML
    void deActiveFood(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < foodsList.getItems().size(); i++) {
            if (foodsList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            if (Admin.loggedInRestaurant.getFoods().get(index).isActive()){
                Admin.loggedInRestaurant.getFoods().get(index).setActive(false);
                foodsList.getItems().clear();
                foodsList.getItems().addAll(Admin.loggedInRestaurant.getFoods());
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Food DeActivated Successfully");
                alert.showAndWait();
            }
            else {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Food  is already DeActive");
                alert.showAndWait();
            }
        }
    }

    @FXML
    void addFoodPressed(ActionEvent event) {
        if (txtName.getText().equals("")||txtFoodType.getText().equals("")||txtPrice.getText().equals("")){

        }
        else {
            try {
                int price = Integer.parseInt(txtPrice.getText());
                boolean checkFoodType = false;
                for (String item :
                        Admin.loggedInRestaurant.getFoodtype()) {
                    if (item.equals(txtFoodType.getText()))
                        checkFoodType = true;
                }
                if (checkFoodType){
                    Admin.loggedInRestaurant.getFoods().add(new Food(txtName.getText(),txtFoodType.getText(),price,Admin.loggedInAdmin.getUserID()));
                    foodsList.getItems().clear();
                    foodsList.getItems().addAll(Admin.loggedInRestaurant.getFoods());
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setContentText("Food added Successfully");
                    alert.showAndWait();
                    txtFoodType.setText("");
                    txtPrice.setText("");
                    txtName.setText("");
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.setTitle("Information");
                    alert.setContentText("We don't have this food type");
                    alert.showAndWait();
                    txtFoodType.setText("");
                }
            }
            catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("Price invalid");
                alert.showAndWait();
                txtPrice.setText("");
            }
        }
    }

    @FXML
    void discountPressed(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < foodsList.getItems().size(); i++) {
            if (foodsList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            try {
                int percent = Integer.parseInt(txtDiscountPercent.getText());
                int timeStop = Integer.parseInt(txtTimeStop.getText());
                Admin.loggedInRestaurant.getFoods().get(index).setDiscount(percent);
                Admin.loggedInRestaurant.getFoods().get(index).setTimeStop(timeStop);
                foodsList.getItems().clear();
                foodsList.getItems().addAll(Admin.loggedInRestaurant.getFoods());
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("information");
                alert.setContentText("Discount set successfully");
                alert.showAndWait();
                txtDiscountPercent.setText("");
                txtTimeStop.setText("");
            }
            catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("percent or time invalid");
                alert.showAndWait();
                txtDiscountPercent.setText("");
                txtTimeStop.setText("");
            }
        }
    }

    @FXML
    void edit(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < foodsList.getItems().size(); i++) {
            if (foodsList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            anchorPane1.setVisible(false);
            anchorPane2.setVisible(true);
        }
    }

    @FXML
    void showFoodsPressed(ActionEvent event) {
        foodsList.setVisible(true);
        foodsList.getItems().clear();
        foodsList.getItems().addAll(Admin.loggedInRestaurant.getFoods());
    }

    @FXML
    void editNamePressed(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < foodsList.getItems().size(); i++) {
            if (foodsList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            if (!txtNewName.getText().equals("")){
                Admin.loggedInRestaurant.getFoods().get(index).setFoodName(txtNewName.getText());
                foodsList.getItems().clear();
                foodsList.getItems().addAll(Admin.loggedInRestaurant.getFoods());
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("information");
                alert.setContentText("FoodName edited successfully");
                alert.showAndWait();
                txtNewName.setText("");
                anchorPane2.setVisible(false);
                anchorPane1.setVisible(true);
            }
        }
    }

    @FXML
    void editPricePressed(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < foodsList.getItems().size(); i++) {
            if (foodsList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
            try {
                int price = Integer.parseInt(txtNewPrice.getText());
                Admin.loggedInRestaurant.getFoods().get(index).setPrice(price);
                foodsList.getItems().clear();
                foodsList.getItems().addAll(Admin.loggedInRestaurant.getFoods());
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("information");
                alert.setContentText("FoodPrice edited successfully");
                alert.showAndWait();
                txtNewPrice.setText("");
                anchorPane2.setVisible(false);
                anchorPane1.setVisible(true);
            }
            catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("invalid price");
                alert.showAndWait();
                txtNewPrice.setText("");
            }
    }

    @FXML
    void back2Pressed(ActionEvent event) {
        anchorPane1.setVisible(true);
        anchorPane2.setVisible(false);
    }

}
