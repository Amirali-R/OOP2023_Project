package com.example.projectoop_phase2;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import model.Admin;
import model.Customer;
import model.Restaurant;

import java.io.IOException;
import java.util.ArrayList;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        //Admin.allAdmins.add(new Admin("mohammad","1234"));
        Admin.loggedInAdmin = new Admin("mohammad","1234","09908608044");
        Customer.allCustomer.add(new Customer("mohammad","1234","09908608044"));
        // test
        ArrayList<String> res = new ArrayList<>();
        res.add("fast food");
        res.add("italian");
        new Restaurant("Rs1",res,0);
        new Restaurant("Rs2",res,1);
        new Restaurant("Rs3",res,2);
        new Restaurant("Rs1",res,3);
        new Restaurant("Rs1",res,4);
        new Restaurant("Rs3",res,5);
        /////////////////////
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 1086, 738);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}