package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Admin;
import model.Comment;

import java.io.IOException;

public class OpenAdminsRestaurantController {

    @FXML
    private Button btnBack;

    @FXML
    private TextField txtAdminId;

    @FXML
    private TextField txtRestaurantId;

    @FXML
    private TextField txtInputLocation;

    @FXML
    private ListView<Comment> commentList;

    @FXML
    private TextField txtRating;

    @FXML
    private Button btnback2;

    @FXML
    private AnchorPane anchorPane1;

    @FXML
    private AnchorPane anchorPane2;

    @FXML
    private TextField txtComment;

    @FXML
    private TextField txtresponse;

    @FXML
    private Button btnBacl3;

    @FXML
    private ListView<String> typesList;

    @FXML
    private AnchorPane anchorPane3;

    @FXML
    private TextField txtNewType;

    @FXML
    private Button btnDone;



    @FXML
    void backPressed(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("WelcomeAdmin.fxml"));
        Scene newScene = new Scene(anchorPane,960,635);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void showLocation(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Information");
        alert.setContentText(String.valueOf(Admin.loggedInRestaurant.getLocation()));
        alert.showAndWait();

        txtAdminId.setText("Admin ID: "+Admin.loggedInAdmin.getUserID());
        txtRestaurantId.setText("Restaurant ID: "+Admin.loggedInRestaurant.getId());
    }

    @FXML
    void editFoodType(ActionEvent event) {   // anchorPane3
        anchorPane1.setVisible(false);
        anchorPane3.setVisible(true);
        txtNewType.setText("");
        typesList.getItems().clear();
        typesList.getItems().addAll(Admin.loggedInRestaurant.getFoodtype());
    }

    @FXML
    void editLocation(ActionEvent event) {
        if (txtInputLocation.getText().equals("")){

        }
        else {
            try {
                int newLocation = Integer.parseInt(txtInputLocation.getText());
                Admin.loggedInRestaurant.setLocation(newLocation);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("location edited successfully");
                alert.showAndWait();
                txtAdminId.setText(Admin.loggedInAdmin.getUserID());
                txtRestaurantId.setText(Admin.loggedInRestaurant.getId());
                txtInputLocation.setText("");
            }
            catch (NumberFormatException e){

            }
        }
    }

    @FXML
    void showMenu(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnBack.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("OpenAdminsMenu.fxml"));    //           Here we go
        Scene newScene = new Scene(anchorPane,950,630);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void showComments(ActionEvent event) {
        Admin.loggedInRestaurant.printComments();
        anchorPane1.setVisible(false);
        anchorPane2.setVisible(true);
        txtComment.setText("");
        txtRating.setText("");
        commentList.getItems().clear();
        commentList.getItems().addAll(Admin.loggedInRestaurant.getComments());
    }

    @FXML
    void addComment(ActionEvent event) {
        if (txtComment.getText().equals("")||txtRating.getText().equals("")){

        }
        else {
            try {
                int rating = Integer.parseInt(txtRating.getText());
                String comment = txtComment.getText();
                new Comment(comment,rating,Admin.loggedInAdmin.getUserID(),true);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Commented successfully");
                alert.showAndWait();
                txtRating.setText("");
                txtComment.setText("");
                showList(); ///   test
            }
            catch (NumberFormatException e){
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("rating invalid");
                alert.showAndWait();
                //txtRating.setText("");
                txtComment.setText("");
            }
        }
    }

    @FXML
    void response(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < commentList.getItems().size(); i++) {
            if (commentList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }
        if (index!=-1){
            if (!txtresponse.getText().equals("")){
                Admin.loggedInRestaurant.getComments().get(index).setResponse(txtresponse.getText());
                //txtComment.setText(txtresponse.getText());
                //txtRating.setText(Admin.loggedInRestaurant.getComments().get(index).getCommentID());
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Information");
                alert.setContentText("Response successfully");
                alert.showAndWait();
                txtresponse.setText("");
                showList();
            }
        }
    }

    @FXML
    void back2(ActionEvent event) {
        anchorPane2.setVisible(false);
        anchorPane1.setVisible(true);
    }

    public void showList(ActionEvent event) {
        commentList.getItems().clear();
        commentList.getItems().addAll(Admin.loggedInRestaurant.getComments());
    }

    public void showList() {
        commentList.getItems().clear();
        commentList.getItems().addAll(Admin.loggedInRestaurant.getComments());
    }

    public void back3(ActionEvent event) {
        anchorPane1.setVisible(true);
        anchorPane3.setVisible(false);
    }

    public void done(ActionEvent event) {
        int index = -1;
        for (int i = 0; i < typesList.getItems().size(); i++) {
            if (typesList.getSelectionModel().isSelected(i)){
                index = i;
            }
        }

        if (index!=-1 && (!txtNewType.getText().equals(""))){
            Admin.loggedInRestaurant.getFoodtype().set(index,txtNewType.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Food type edited successfully");
            alert.showAndWait();
            anchorPane3.setVisible(false);
            anchorPane1.setVisible(true);
            txtNewType.setText("");
        }
    }

    public void addNewFoodType(ActionEvent event) {
        if (!txtNewType.getText().equals("")){
            Admin.loggedInRestaurant.getFoodtype().add(txtNewType.getText());
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Information");
            alert.setContentText("Food type added successfully");
            alert.showAndWait();
            anchorPane3.setVisible(false);
            anchorPane1.setVisible(true);
            txtNewType.setText("");
        }
    }
}
