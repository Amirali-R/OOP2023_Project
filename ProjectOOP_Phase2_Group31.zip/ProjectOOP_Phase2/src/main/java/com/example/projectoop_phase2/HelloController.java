package com.example.projectoop_phase2;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import model.Admin;
import model.Customer;

import java.io.IOException;
import java.util.Random;

public class HelloController {

    @FXML
    private AnchorPane anchorPane1;

    @FXML
    private AnchorPane anchorPane2;

    @FXML
    private TextField txtUsername;

    @FXML
    private Button btnSignUp;

    @FXML
    private Button btnSignIn;

    @FXML
    private RadioButton btnAdmin;

    @FXML
    private RadioButton btnCustomer;

    @FXML
    private TextField txtPassword;

    @FXML
    private Label lblCapcha;

    @FXML
    private TextField txtEnterCapcha;

    boolean created = false;


    public void signInPressed(ActionEvent event) throws IOException {
        if (btnAdmin.isSelected()&&btnCustomer.isSelected()){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setContentText("Choose one Admin/Customer");
            alert.showAndWait();
        }
        else if (txtUsername.getText().equals("")||txtPassword.getText().equals("")||txtEnterCapcha.getText().equals("")){
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning");
            alert.setContentText("Enter username and password and captcha");
            alert.showAndWait();
        }
        else if (btnAdmin.isSelected()){
            String username,password;
            username = txtUsername.getText();
            password = txtPassword.getText();
            if (this.checkAdminUsernameExist(username)){
                int index = this.getIndex(username,true);
                if (txtEnterCapcha.getText().equals(lblCapcha.getText())){
                    if (Admin.allAdmins.get(index).getPassword().equals(password)) {
                        Admin.loggedInAdmin = Admin.allAdmins.get(index);
                        Stage stage = (Stage) btnSignUp.getScene().getWindow();
                        stage.close();
                        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("WelcomeAdmin.fxml"));   ///   Here we go for Admin
                        Scene newScene = new Scene(anchorPane, 960, 635);
                        stage.setScene(newScene);
                        stage.show();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Warning");
                        alert.setContentText("input password incorrect");
                        alert.showAndWait();
                    }
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("input captcha incorrect");
                    alert.showAndWait();
                    txtEnterCapcha.setText("");
                }
            }
            else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("Username does not exist!");
                alert.showAndWait();
            }
        }
        else if (btnCustomer.isSelected()){
            String username,password;
            username = txtUsername.getText();
            password = txtPassword.getText();
            if (this.checkCustomerUsernameExist(username)){
                int index = this.getIndex(username,false);
                if (txtEnterCapcha.getText().equals(lblCapcha.getText())){
                    if (Customer.allCustomer.get(index).getPassword().equals(password)) {
                        Customer.loggedInCustomer = Customer.allCustomer.get(index);
                        Stage stage = (Stage) btnSignUp.getScene().getWindow();
                        stage.close();
                        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("welcomeToCustomer.fxml"));    //   Here we go for Customer
                        Scene newScene = new Scene(anchorPane, 950, 630);
                        stage.setScene(newScene);
                        stage.show();
                    } else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Warning");
                        alert.setContentText("input password incorrect");
                        alert.showAndWait();
                    }
                }
                else {
                    Alert alert = new Alert(Alert.AlertType.WARNING);
                    alert.setTitle("Warning");
                    alert.setContentText("input captcha incorrect");
                    alert.showAndWait();
                    txtEnterCapcha.setText("");
                }
            }
            else {
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Warning");
                alert.setContentText("Username does not exist!");
                alert.showAndWait();
            }
        }
    }

    private int getIndex(String username, boolean adminSend) {
        if (adminSend){
            for (int i = 0; i < Admin.allAdmins.size(); i++) {
                if (Admin.allAdmins.get(i).getUsername().equals(username))
                    return i;
            }
        }
        else {
            for (int i = 0; i < Customer.allCustomer.size(); i++) {
                if (Customer.allCustomer.get(i).getUsername().equals(username))
                    return i;
            }
        }
        return -1;
    }

    private boolean checkCustomerUsernameExist(String username) {
        for (Customer item :
                Customer.allCustomer) {
            if (item.getUsername().equals(username))
                return true;
        }
        return false;
    }

    private boolean checkPasswordFormat(String password) {   //        Not completed!!!
        return true;
    }

    private boolean checkAdminUsernameExist(String username) {
        for (Admin item :
                Admin.allAdmins) {
            if (item.getUsername().equals(username))
                return true;
        }
        return false;
    }

    public void signUpPressed(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnSignUp.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("SignUpView.fxml"));
        Scene newScene = new Scene(anchorPane,760,550);
        stage.setScene(newScene);
        stage.show();
    }

    @FXML
    void exitPresse(ActionEvent event) {
        anchorPane1.setVisible(false);
        anchorPane2.setVisible(true);
    }

    private boolean sure() {

        return false;
    }

    public void yesPressed(ActionEvent event) {
        Stage stage = (Stage) btnSignUp.getScene().getWindow();                                     //   Here save the changes
        stage.close();
    }

    public void noPressed(ActionEvent event) {
        anchorPane1.setVisible(true);
        anchorPane2.setVisible(false);
    }

    public void newCapchaPressed(ActionEvent event) {
        char data[]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9'};
        char index[]=new char[7];

        Random r=new Random();
        int i =0;

        for( i=0;i<(index.length);i++)
        {
            int ran=r.nextInt(data.length);
            index[i]=data[ran];
        }
         lblCapcha.setText(String.valueOf(index));
    }

    public void forgetPasswordPressed(ActionEvent event) throws IOException {
        Stage stage = (Stage) btnSignUp.getScene().getWindow();
        stage.close();
        AnchorPane anchorPane = (AnchorPane) FXMLLoader.load(getClass().getResource("forgetPassword.fxml"));
        Scene newScene = new Scene(anchorPane,950,630);
        stage.setScene(newScene);
        stage.show();
    }

    public void createNewCapcha(MouseEvent mouseEvent) {
        if (lblCapcha.getText().equals("Label"))
        {
            char data[] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9'};
            char index[] = new char[7];

            Random r = new Random();
            int i = 0;

            for (i = 0; i < (index.length); i++) {
                int ran = r.nextInt(data.length);
                index[i] = data[ran];
            }
            lblCapcha.setText(String.valueOf(index));
        }
    }
}