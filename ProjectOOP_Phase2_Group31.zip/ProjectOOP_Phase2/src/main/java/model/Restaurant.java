package model;

import java.util.ArrayList;
import java.util.Random;

public class Restaurant {

    public static ArrayList<Restaurant> allRestaurants = new ArrayList<>();        //  Static field
    private ArrayList<Restaurant> lastSend = new ArrayList<>();


    private String name,id;
    private ArrayList<String> foodtype;
    private int location;
    private ArrayList<Comment> comments = new ArrayList<>();
    private ArrayList<Food> foods  = new ArrayList<>();


    public Restaurant(String name, ArrayList<String> foodType,int location) {
        this.name = name;

        Random random = new Random();
        this.id = String.valueOf(random.nextInt(100000))+String.valueOf(random.nextInt(10000));
        this.foodtype = foodType;

        this.location = location;

        //Restaurant.allRestaurants.add(this);

        Admin admin = Admin.loggedInAdmin;

        admin.adminsRestaurants.add(this);
        Restaurant.allRestaurants.add(this);
    }



    public ArrayList<Restaurant> getLastSend() {
        return lastSend;
    }

    public ArrayList<Restaurant> viewRestaurants(){
        lastSend.clear();
        System.out.println(lastSend.size());
        for (Restaurant item :
                allRestaurants) {
            lastSend.add(item);
        }
        return lastSend;
    }

    public ArrayList<Restaurant> viewSearch(String restaurantName){
        lastSend.clear();
        System.out.println(lastSend.size());
        for (Restaurant item :
                allRestaurants) {
            if (item.getName().equals(restaurantName))
                lastSend.add(item);
        }
        return lastSend;
    }

    public ArrayList<Comment> getComments() {
        return comments;
    }

    public ArrayList<Food> getFoods() {
        return foods;
    }

    public void setFoods(ArrayList<Food> foods) {
        this.foods = foods;
    }

    public void setComments(ArrayList<Comment> comments) {
        this.comments = comments;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getId() {
        return id;
    }



    public void setId(String id) {
        this.id = id;
    }


    public ArrayList<String> getFoodtype() {
        return foodtype;
    }


    public void setFoodtype(ArrayList<String> foodtype) {
        this.foodtype = foodtype;
    }


    public int getLocation() {
        return location;
    }


    public void setLocation(int location) {
        this.location = location;
    }


    @Override
    public String toString() {
        System.out.println(" name: " + this.name + "  ID:" + this.getId() + "   foodType: " + this.foodtype);
        return " name: " + this.name + "  ID:" + this.getId() + "   foodType: " + this.foodtype;//+this.getFoodType();          <<== test
    }

    public void printComments() {
        for (Comment item :
                comments) {
            System.out.println(item);
        }
    }
}
