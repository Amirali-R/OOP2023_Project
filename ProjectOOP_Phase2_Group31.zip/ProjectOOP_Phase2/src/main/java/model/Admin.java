package model;

import java.util.ArrayList;
import java.util.Random;

public class Admin {
    public ArrayList<Restaurant> adminsRestaurants;// for admin
    public static ArrayList<Admin> allAdmins = new ArrayList<>();
    public static Admin loggedInAdmin = null;
    public static Restaurant loggedInRestaurant = null;
    public static Food loggedInFood = null;

    private ArrayList<Restaurant> lastReturned = new ArrayList<>();
    private String userID;
    private String username;
    private String password;
    private String phone;


    public Admin(String username, String password,String phone) {
        adminsRestaurants = new ArrayList<>();
        this.username = username;
        this.password = password;
        this.phone = phone;
        Random random = new Random();
        userID = String.valueOf(random.nextInt(1000000))+String.valueOf(random.nextInt(1000));
        Admin.allAdmins.add(this);
    }

    public String getPhone() {
        return phone;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserID() {
        return userID;
    }

    public ArrayList<String> showSearch(String name){
        lastReturned.clear();
        ArrayList<String> ret = new ArrayList<>();
        for (int i = 0; i < Admin.loggedInAdmin.adminsRestaurants.size(); i++) {
            if (Admin.loggedInAdmin.adminsRestaurants.get(i).getName().equals(name)) {
                ret.add(Admin.loggedInAdmin.adminsRestaurants.get(i).toString());
                lastReturned.add(Admin.loggedInAdmin.adminsRestaurants.get(i));
            }
        }
        return ret;
    }

    public ArrayList<String> showList(){
        lastReturned.clear();
        ArrayList<String> ret = new ArrayList<>();
        for (int i = 0; i < Admin.loggedInAdmin.adminsRestaurants.size(); i++) {
            ret.add(Admin.loggedInAdmin.adminsRestaurants.get(i).toString());
            System.out.println("test==>>  "+Admin.loggedInAdmin.adminsRestaurants.get(i).toString());
            lastReturned.add(Admin.loggedInAdmin.adminsRestaurants.get(i));
        }
        return ret;
    }

    public void findSelectedRestaurant(int index){
        loggedInRestaurant = lastReturned.get(index);
        //System.out.println(loggedInRestaurant.toString());
    }
}
