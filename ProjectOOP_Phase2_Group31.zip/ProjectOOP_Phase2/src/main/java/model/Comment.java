package model;

import java.util.Random;

public class Comment {
    private String txt;
    private String response = "nothing";
    private String userID;
    private String commentID;
    private int rating;

    public Comment(String txt, int rating, String id,boolean isAdmin) {
        this.txt = txt;
        this.userID = id;
        this.rating = rating;
        Random random = new Random();
        this.commentID = String.valueOf(random.nextInt(100000));
        if (isAdmin)
        Admin.loggedInRestaurant.getComments().add(this);
        else
            Customer.loggedInRestaurant.getComments().add(this);
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getCommentID() {
        return commentID;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getTxt() {
        return txt;
    }

    public void setTxt(String txt) {
        this.txt = txt;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    @Override
    public String toString() {
        return "Comment: "+getTxt()+"  userId: "+getUserID()+" CommentID: "+getCommentID()+" response: "+getResponse()+" Rating: "+getRating();
    }
}

