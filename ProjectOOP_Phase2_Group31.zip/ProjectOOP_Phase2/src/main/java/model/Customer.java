package model;

import java.util.ArrayList;
import java.util.Random;

public class Customer {

    public static ArrayList<Customer> allCustomer = new ArrayList<Customer>();
    public static  Customer loggedInCustomer = null;
    public static Restaurant loggedInRestaurant = null;
    public static Food loggedInFood = null;

    private ArrayList<Cart> carts = new ArrayList<>();
    private ArrayList<Order> orderHistory = new ArrayList<>();
    private String userID;
    private String username;
    private String password;
    private double charge = 1000;
    private String phone;

    public Customer(String username, String password,String phone) {
        this.username = username;
        this.password = password;
        this.phone = phone;
        Random random = new Random();
        userID = String.valueOf(random.nextInt(1000000))+String.valueOf(random.nextInt(1000));
        Customer.allCustomer.add(this);
    }

    public void buyProduct(double cost){
        this.charge -= cost;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public ArrayList<Order> getOrderHistory() {
        return orderHistory;
    }

    public void setOrderHistory(ArrayList<Order> orderHistory) {
        this.orderHistory = orderHistory;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public double getCharge() {
        return charge;
    }

    public void setCharge(double charge) {
        this.charge += charge;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public ArrayList<Cart> getCarts() {
        return carts;
    }

    public void setCarts(ArrayList<Cart> carts) {
        this.carts = carts;
    }
}
