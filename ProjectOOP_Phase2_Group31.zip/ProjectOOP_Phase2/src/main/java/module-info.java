module com.example.projectoop_phase2 {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.bootstrapfx.core;

    opens com.example.projectoop_phase2 to javafx.fxml;
    exports com.example.projectoop_phase2;
}