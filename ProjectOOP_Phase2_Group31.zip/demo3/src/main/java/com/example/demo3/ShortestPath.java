package com.example.demo3;

import java.lang.*;
import java.util.ArrayList;
import java.util.Scanner;

class ShortestPath
{
    static final int V=67;
    public static int Distance = 0;
    public static int[] previousNode = new int[67];
    public static ArrayList<Integer> ShortestPath = new ArrayList<>();
    public static int minDistance(int distance[], Boolean sptSet[])
    {
        int min = Integer.MAX_VALUE, min_index=-1;
        for (int v = 0; v < V; v++){
            if (sptSet[v] == false && distance[v] <= min)
            {
                min = distance[v];
                min_index = v;
            }
        }
        return min_index;
    }
    public static void Path(int[] array, int src, int end){
        int i = end;
        ShortestPath.add(i);
        while(true){
            ShortestPath.add(array[i]);
            i = array[i];
            if(i==src){
                break;
            }
        }
    }
    public static void printSolution(int distance[], int src, int End) {
        Distance = distance[End];
        Path(previousNode,src,End);
    }
    public static void dijkstra(int graph[][], int start, int end) {
        int distance[] = new int[V];
        Boolean sptSet[] = new Boolean[V];
        for (int i = 0; i < V; i++) {
            distance[i] = Integer.MAX_VALUE;
            sptSet[i] = false;
        }
        distance[start] = 0;
        for (int count = 0; count < V-1; count++) {
            int u = minDistance(distance, sptSet);
            sptSet[u] = true;
            for (int v = 0; v < V; v++){
                if (!sptSet[v] && graph[u][v]!=0 && distance[u] != Integer.MAX_VALUE && distance[u]+graph[u][v] < distance[v]){
                    distance[v] = distance[u] + graph[u][v];
                    previousNode[v]=u;
                }
            }
        }
        printSolution(distance, start, end);
    }
}
