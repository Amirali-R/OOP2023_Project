package com.example.demo3;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;

import java.util.Random;

public class HelloController {
    public static float TotalTraffic = 0;
    public static Random rand = new Random();
    @FXML
    private TextField start;
    @FXML
    private TextField end;
    @FXML
    private ImageView map1;
    @FXML
    private ImageView map2;
    @FXML
    private Line line1;
    @FXML
    private Line line2;
    @FXML
    private Line line3;
    @FXML
    private Line line4;
    @FXML
    private Line line5;
    @FXML
    private Line line6;
    @FXML
    private Line line7;
    @FXML
    private Line line8;
    @FXML
    private Line line9;
    @FXML
    private Line line10;
    @FXML
    private Line line11;
    @FXML
    private Line line12;
    @FXML
    private Line line13;
    @FXML
    private Line line14;
    @FXML
    private Line line15;
    @FXML
    private Line line16;
    @FXML
    private Line line17;
    @FXML
    private Line line18;
    @FXML
    private Line line19;
    @FXML
    private Line line20;
    @FXML
    private Line line21;
    @FXML
    private Line line22;
    @FXML
    private Line line23;
    @FXML
    private Line line24;
    @FXML
    private Line line25;
    @FXML
    private Line line26;
    @FXML
    private Line line27;
    @FXML
    private Line line28;
    @FXML
    private Line line29;
    @FXML
    private Line line30;
    @FXML
    private Line line31;
    @FXML
    private Line line32;
    @FXML
    private Line line33;
    @FXML
    private Line line34;
    @FXML
    private Line line35;
    @FXML
    private Line line36;
    @FXML
    private Line line37;
    @FXML
    private Line line38;
    @FXML
    private Line line39;
    @FXML
    private Line line40;
    @FXML
    private Line line41;
    @FXML
    private Line line42;
    @FXML
    private Line line43;
    @FXML
    private Line line44;
    @FXML
    private Line line45;
    @FXML
    private Line line46;
    @FXML
    private Line line47;
    @FXML
    private Line line48;
    @FXML
    private Line line49;
    @FXML
    private Line line50;
    @FXML
    private Line line51;
    @FXML
    private Line line52;
    @FXML
    private Line line53;
    @FXML
    private Line line54;
    @FXML
    private Line line55;
    @FXML
    private Line line56;
    @FXML
    private Line line57;
    @FXML
    private Line line58;
    @FXML
    private Line line59;
    @FXML
    private Line line60;
    @FXML
    private Line line61;
    @FXML
    private Line line62;
    @FXML
    private Line line63;
    @FXML
    private Line line64;
    @FXML
    private Line line65;
    @FXML
    private Line line66;
    @FXML
    private Line line67;
    @FXML
    private Line line68;
    @FXML
    private Line line69;
    @FXML
    private Line line70;
    @FXML
    private Line line71;
    @FXML
    private Line line72;
    @FXML
    private Line line73;
    @FXML
    private Line line74;
    @FXML
    private Line line75;
    @FXML
    private Line line76;
    @FXML
    private Line line77;
    @FXML
    private Line line78;
    @FXML
    private Line line79;
    @FXML
    private Line line80;
    @FXML
    private Line line81;
    @FXML
    private Line line82;
    @FXML
    private Line line83;
    @FXML
    private Line line84;
    @FXML
    private Line line85;
    @FXML
    private Line line86;
    @FXML
    private Line line87;
    @FXML
    private Line line88;
    @FXML
    private Line line89;
    @FXML
    private Line line90;
    @FXML
    private Button go;
    @FXML
    private Button back;
    @FXML
    private Label startLabel;
    @FXML
    private Label endLabel;
    @FXML
    private Label distance;
    @FXML
    private Label estimatedTime;

    public void go(){
        ShortestPath.ShortestPath.clear();
        int S = Integer.parseInt(start.getText());
        int E = Integer.parseInt(end.getText());
        Graph.toMatrix();
        ShortestPath.dijkstra(Graph.graphMatrix,S,E);
        map1.setVisible(false);
        map2.setVisible(true);
        go.setVisible(false);
        back.setVisible(true);
        startLabel.setVisible(false);
        endLabel.setVisible(false);
        start.setVisible(false);
        end.setVisible(false);
        TotalTraffic = 0;
        for(int i=0; i<ShortestPath.ShortestPath.size()-1; i++){
            if(ShortestPath.ShortestPath.get(i)==1 && ShortestPath.ShortestPath.get(i+1)==2){
                showPath(line1);
            }
            else if(ShortestPath.ShortestPath.get(i)==2 && ShortestPath.ShortestPath.get(i+1)==1){
                showPath(line1);
            }
            if(ShortestPath.ShortestPath.get(i)==1 && ShortestPath.ShortestPath.get(i+1)==7){
                showPath(line2);
            }
            else if(ShortestPath.ShortestPath.get(i)==7 && ShortestPath.ShortestPath.get(i+1)==1){
                showPath(line2);
            }
            if(ShortestPath.ShortestPath.get(i)==2 && ShortestPath.ShortestPath.get(i+1)==8){
                showPath(line3);
            }
            else if(ShortestPath.ShortestPath.get(i)==8 && ShortestPath.ShortestPath.get(i+1)==2){
                showPath(line3);
            }
            if(ShortestPath.ShortestPath.get(i)==2 && ShortestPath.ShortestPath.get(i+1)==3){
                showPath(line4);
            }
            else if(ShortestPath.ShortestPath.get(i)==3 && ShortestPath.ShortestPath.get(i+1)==2){
                showPath(line4);
            }
            if(ShortestPath.ShortestPath.get(i)==3 && ShortestPath.ShortestPath.get(i+1)==6){
                showPath(line5);
            }
            else if(ShortestPath.ShortestPath.get(i)==6 && ShortestPath.ShortestPath.get(i+1)==3){
                showPath(line5);
            }
            if(ShortestPath.ShortestPath.get(i)==3 && ShortestPath.ShortestPath.get(i+1)==4){
                showPath(line6);
            }
            else if(ShortestPath.ShortestPath.get(i)==4 && ShortestPath.ShortestPath.get(i+1)==3){
                showPath(line6);
            }
            if(ShortestPath.ShortestPath.get(i)==4 && ShortestPath.ShortestPath.get(i+1)==5){
                showPath(line7);
            }
            else if(ShortestPath.ShortestPath.get(i)==5 && ShortestPath.ShortestPath.get(i+1)==4){
                showPath(line7);
            }
            if(ShortestPath.ShortestPath.get(i)==5 && ShortestPath.ShortestPath.get(i+1)==6){
                showPath(line8);
            }
            else if(ShortestPath.ShortestPath.get(i)==6 && ShortestPath.ShortestPath.get(i+1)==5){
                showPath(line8);
            }
            if(ShortestPath.ShortestPath.get(i)==5 && ShortestPath.ShortestPath.get(i+1)==11){
                showPath(line9);
            }
            else if(ShortestPath.ShortestPath.get(i)==11 && ShortestPath.ShortestPath.get(i+1)==5){
                showPath(line9);
            }
            if(ShortestPath.ShortestPath.get(i)==6 && ShortestPath.ShortestPath.get(i+1)==9){
                showPath(line10);
            }
            else if(ShortestPath.ShortestPath.get(i)==9 && ShortestPath.ShortestPath.get(i+1)==6){
                showPath(line10);
            }
            if(ShortestPath.ShortestPath.get(i)==7 && ShortestPath.ShortestPath.get(i+1)==8){
                showPath(line11);
            }
            else if(ShortestPath.ShortestPath.get(i)==8 && ShortestPath.ShortestPath.get(i+1)==7){
                showPath(line11);
            }
            if(ShortestPath.ShortestPath.get(i)==8 && ShortestPath.ShortestPath.get(i+1)==9){
                showPath(line12);
            }
            else if(ShortestPath.ShortestPath.get(i)==9 && ShortestPath.ShortestPath.get(i+1)==8){
                showPath(line12);
            }
            if(ShortestPath.ShortestPath.get(i)==8 && ShortestPath.ShortestPath.get(i+1)==51){
                showPath(line13);
            }
            else if(ShortestPath.ShortestPath.get(i)==51 && ShortestPath.ShortestPath.get(i+1)==8){
                showPath(line13);
            }
            if(ShortestPath.ShortestPath.get(i)==9 && ShortestPath.ShortestPath.get(i+1)==10){
                showPath(line14);
            }
            else if(ShortestPath.ShortestPath.get(i)==10 && ShortestPath.ShortestPath.get(i+1)==9){
                showPath(line14);
            }
            if(ShortestPath.ShortestPath.get(i)==9 && ShortestPath.ShortestPath.get(i+1)==48){
                showPath(line15);
            }
            else if(ShortestPath.ShortestPath.get(i)==48 && ShortestPath.ShortestPath.get(i+1)==9){
                showPath(line15);
            }
            if(ShortestPath.ShortestPath.get(i)==10 && ShortestPath.ShortestPath.get(i+1)==11){
                showPath(line16);
            }
            else if(ShortestPath.ShortestPath.get(i)==11 && ShortestPath.ShortestPath.get(i+1)==10){
                showPath(line16);
            }
            if(ShortestPath.ShortestPath.get(i)==10 && ShortestPath.ShortestPath.get(i+1)==47){
                showPath(line17);
            }
            else if(ShortestPath.ShortestPath.get(i)==47 && ShortestPath.ShortestPath.get(i+1)==10){
                showPath(line17);
            }
            if(ShortestPath.ShortestPath.get(i)==11 && ShortestPath.ShortestPath.get(i+1)==12){
                showPath(line18);
            }
            else if(ShortestPath.ShortestPath.get(i)==12 && ShortestPath.ShortestPath.get(i+1)==11){
                showPath(line18);
            }
            if(ShortestPath.ShortestPath.get(i)==12 && ShortestPath.ShortestPath.get(i+1)==13){
                showPath(line19);
            }
            else if(ShortestPath.ShortestPath.get(i)==13 && ShortestPath.ShortestPath.get(i+1)==12){
                showPath(line19);
            }
            if(ShortestPath.ShortestPath.get(i)==12 && ShortestPath.ShortestPath.get(i+1)==45){
                showPath(line20);
            }
            else if(ShortestPath.ShortestPath.get(i)==45 && ShortestPath.ShortestPath.get(i+1)==12){
                showPath(line20);
            }
            if(ShortestPath.ShortestPath.get(i)==13 && ShortestPath.ShortestPath.get(i+1)==14){
                showPath(line21);
            }
            else if(ShortestPath.ShortestPath.get(i)==14 && ShortestPath.ShortestPath.get(i+1)==13){
                showPath(line21);
            }
            if(ShortestPath.ShortestPath.get(i)==13 && ShortestPath.ShortestPath.get(i+1)==44){
                showPath(line22);
            }
            else if(ShortestPath.ShortestPath.get(i)==44 && ShortestPath.ShortestPath.get(i+1)==13){
                showPath(line22);
            }
            if(ShortestPath.ShortestPath.get(i)==14 && ShortestPath.ShortestPath.get(i+1)==15){
                showPath(line23);
            }
            else if(ShortestPath.ShortestPath.get(i)==15 && ShortestPath.ShortestPath.get(i+1)==14){
                showPath(line23);
            }
            if(ShortestPath.ShortestPath.get(i)==14 && ShortestPath.ShortestPath.get(i+1)==43){
                showPath(line24);
            }
            else if(ShortestPath.ShortestPath.get(i)==43 && ShortestPath.ShortestPath.get(i+1)==14){
                showPath(line24);
            }
            if(ShortestPath.ShortestPath.get(i)==15 && ShortestPath.ShortestPath.get(i+1)==16){
                showPath(line25);
            }
            else if(ShortestPath.ShortestPath.get(i)==16 && ShortestPath.ShortestPath.get(i+1)==15){
                showPath(line25);
            }
            if(ShortestPath.ShortestPath.get(i)==15 && ShortestPath.ShortestPath.get(i+1)==40){
                showPath(line26);
            }
            else if(ShortestPath.ShortestPath.get(i)==40 && ShortestPath.ShortestPath.get(i+1)==15){
                showPath(line26);
            }
            if(ShortestPath.ShortestPath.get(i)==16 && ShortestPath.ShortestPath.get(i+1)==17){
                showPath(line27);
            }
            else if(ShortestPath.ShortestPath.get(i)==17 && ShortestPath.ShortestPath.get(i+1)==16){
                showPath(line27);
            }
            if(ShortestPath.ShortestPath.get(i)==16 && ShortestPath.ShortestPath.get(i+1)==24){
                showPath(line28);
            }
            else if(ShortestPath.ShortestPath.get(i)==24 && ShortestPath.ShortestPath.get(i+1)==16){
                showPath(line28);
            }
            if(ShortestPath.ShortestPath.get(i)==17 && ShortestPath.ShortestPath.get(i+1)==18){
                showPath(line29);
            }
            else if(ShortestPath.ShortestPath.get(i)==18 && ShortestPath.ShortestPath.get(i+1)==17){
                showPath(line29);
            }
            if(ShortestPath.ShortestPath.get(i)==18 && ShortestPath.ShortestPath.get(i+1)==19){
                showPath(line30);
            }
            else if(ShortestPath.ShortestPath.get(i)==19 && ShortestPath.ShortestPath.get(i+1)==18){
                showPath(line30);
            }
            if(ShortestPath.ShortestPath.get(i)==19 && ShortestPath.ShortestPath.get(i+1)==20){
                showPath(line31);
            }
            else if(ShortestPath.ShortestPath.get(i)==20 && ShortestPath.ShortestPath.get(i+1)==19){
                showPath(line31);
            }
            if(ShortestPath.ShortestPath.get(i)==20 && ShortestPath.ShortestPath.get(i+1)==21){
                showPath(line32);
            }
            else if(ShortestPath.ShortestPath.get(i)==21 && ShortestPath.ShortestPath.get(i+1)==20){
                showPath(line32);
            }
            if(ShortestPath.ShortestPath.get(i)==21 && ShortestPath.ShortestPath.get(i+1)==22){
                showPath(line33);
            }
            else if(ShortestPath.ShortestPath.get(i)==22 && ShortestPath.ShortestPath.get(i+1)==21){
                showPath(line33);
            }
            if(ShortestPath.ShortestPath.get(i)==22 && ShortestPath.ShortestPath.get(i+1)==23){
                showPath(line34);
            }
            else if(ShortestPath.ShortestPath.get(i)==23 && ShortestPath.ShortestPath.get(i+1)==22){
                showPath(line34);
            }
            if(ShortestPath.ShortestPath.get(i)==22 && ShortestPath.ShortestPath.get(i+1)==27){
                showPath(line35);
            }
            else if(ShortestPath.ShortestPath.get(i)==27 && ShortestPath.ShortestPath.get(i+1)==22){
                showPath(line35);
            }
            if(ShortestPath.ShortestPath.get(i)==23 && ShortestPath.ShortestPath.get(i+1)==24){
                showPath(line36);
            }
            else if(ShortestPath.ShortestPath.get(i)==24 && ShortestPath.ShortestPath.get(i+1)==23){
                showPath(line36);
            }
            if(ShortestPath.ShortestPath.get(i)==23 && ShortestPath.ShortestPath.get(i+1)==26){
                showPath(line37);
            }
            else if(ShortestPath.ShortestPath.get(i)==26 && ShortestPath.ShortestPath.get(i+1)==23){
                showPath(line37);
            }
            if(ShortestPath.ShortestPath.get(i)==24 && ShortestPath.ShortestPath.get(i+1)==25){
                showPath(line38);
            }
            else if(ShortestPath.ShortestPath.get(i)==25 && ShortestPath.ShortestPath.get(i+1)==24){
                showPath(line38);
            }
            if(ShortestPath.ShortestPath.get(i)==25 && ShortestPath.ShortestPath.get(i+1)==26){
                showPath(line39);
            }
            else if(ShortestPath.ShortestPath.get(i)==26 && ShortestPath.ShortestPath.get(i+1)==25){
                showPath(line39);
            }
            if(ShortestPath.ShortestPath.get(i)==25 && ShortestPath.ShortestPath.get(i+1)==33){
                showPath(line40);
            }
            else if(ShortestPath.ShortestPath.get(i)==33 && ShortestPath.ShortestPath.get(i+1)==25){
                showPath(line40);
            }
            if(ShortestPath.ShortestPath.get(i)==26 && ShortestPath.ShortestPath.get(i+1)==27){
                showPath(line41);
            }
            else if(ShortestPath.ShortestPath.get(i)==27 && ShortestPath.ShortestPath.get(i+1)==26){
                showPath(line41);
            }
            if(ShortestPath.ShortestPath.get(i)==26 && ShortestPath.ShortestPath.get(i+1)==29){
                showPath(line42);
            }
            else if(ShortestPath.ShortestPath.get(i)==29 && ShortestPath.ShortestPath.get(i+1)==26){
                showPath(line42);
            }
            if(ShortestPath.ShortestPath.get(i)==27 && ShortestPath.ShortestPath.get(i+1)==28){
                showPath(line43);
            }
            else if(ShortestPath.ShortestPath.get(i)==28 && ShortestPath.ShortestPath.get(i+1)==27){
                showPath(line43);
            }
            if(ShortestPath.ShortestPath.get(i)==28 && ShortestPath.ShortestPath.get(i+1)==29){
                showPath(line44);
            }
            else if(ShortestPath.ShortestPath.get(i)==29 && ShortestPath.ShortestPath.get(i+1)==28){
                showPath(line44);
            }
            if(ShortestPath.ShortestPath.get(i)==28 && ShortestPath.ShortestPath.get(i+1)==30){
                showPath(line45);
            }
            else if(ShortestPath.ShortestPath.get(i)==30 && ShortestPath.ShortestPath.get(i+1)==28){
                showPath(line45);
            }
            if(ShortestPath.ShortestPath.get(i)==29 && ShortestPath.ShortestPath.get(i+1)==31){
                showPath(line46);
            }
            else if(ShortestPath.ShortestPath.get(i)==31 && ShortestPath.ShortestPath.get(i+1)==29){
                showPath(line46);
            }
            if(ShortestPath.ShortestPath.get(i)==30 && ShortestPath.ShortestPath.get(i+1)==31){
                showPath(line47);
            }
            else if(ShortestPath.ShortestPath.get(i)==31 && ShortestPath.ShortestPath.get(i+1)==30){
                showPath(line47);
            }
            if(ShortestPath.ShortestPath.get(i)==30 && ShortestPath.ShortestPath.get(i+1)==36){
                showPath(line48);
            }
            else if(ShortestPath.ShortestPath.get(i)==36 && ShortestPath.ShortestPath.get(i+1)==30){
                showPath(line48);
            }
            if(ShortestPath.ShortestPath.get(i)==31 && ShortestPath.ShortestPath.get(i+1)==32){
                showPath(line49);
            }
            else if(ShortestPath.ShortestPath.get(i)==32 && ShortestPath.ShortestPath.get(i+1)==31){
                showPath(line49);
            }
            if(ShortestPath.ShortestPath.get(i)==32 && ShortestPath.ShortestPath.get(i+1)==33){
                showPath(line50);
            }
            else if(ShortestPath.ShortestPath.get(i)==33 && ShortestPath.ShortestPath.get(i+1)==32){
                showPath(line50);
            }
            if(ShortestPath.ShortestPath.get(i)==32 && ShortestPath.ShortestPath.get(i+1)==34){
                showPath(line51);
            }
            else if(ShortestPath.ShortestPath.get(i)==34 && ShortestPath.ShortestPath.get(i+1)==32){
                showPath(line51);
            }
            if(ShortestPath.ShortestPath.get(i)==33 && ShortestPath.ShortestPath.get(i+1)==40){
                showPath(line52);
            }
            else if(ShortestPath.ShortestPath.get(i)==40 && ShortestPath.ShortestPath.get(i+1)==33){
                showPath(line52);
            }
            if(ShortestPath.ShortestPath.get(i)==34 && ShortestPath.ShortestPath.get(i+1)==35){
                showPath(line53);
            }
            else if(ShortestPath.ShortestPath.get(i)==35 && ShortestPath.ShortestPath.get(i+1)==34){
                showPath(line53);
            }
            if(ShortestPath.ShortestPath.get(i)==34 && ShortestPath.ShortestPath.get(i+1)==39){
                showPath(line54);
            }
            else if(ShortestPath.ShortestPath.get(i)==39 && ShortestPath.ShortestPath.get(i+1)==34){
                showPath(line54);
            }
            if(ShortestPath.ShortestPath.get(i)==34 && ShortestPath.ShortestPath.get(i+1)==56){
                showPath(line55);
            }
            else if(ShortestPath.ShortestPath.get(i)==56 && ShortestPath.ShortestPath.get(i+1)==34){
                showPath(line55);
            }
            if(ShortestPath.ShortestPath.get(i)==35 && ShortestPath.ShortestPath.get(i+1)==37){
                showPath(line56);
            }
            else if(ShortestPath.ShortestPath.get(i)==37 && ShortestPath.ShortestPath.get(i+1)==35){
                showPath(line56);
            }
            if(ShortestPath.ShortestPath.get(i)==35 && ShortestPath.ShortestPath.get(i+1)==38){
                showPath(line57);
            }
            else if(ShortestPath.ShortestPath.get(i)==38 && ShortestPath.ShortestPath.get(i+1)==35){
                showPath(line57);
            }
            if(ShortestPath.ShortestPath.get(i)==36 && ShortestPath.ShortestPath.get(i+1)==37){
                showPath(line58);
            }
            else if(ShortestPath.ShortestPath.get(i)==37 && ShortestPath.ShortestPath.get(i+1)==36){
                showPath(line58);
            }
            if(ShortestPath.ShortestPath.get(i)==37 && ShortestPath.ShortestPath.get(i+1)==52){
                showPath(line59);
            }
            else if(ShortestPath.ShortestPath.get(i)==52 && ShortestPath.ShortestPath.get(i+1)==37){
                showPath(line59);
            }
            if(ShortestPath.ShortestPath.get(i)==39 && ShortestPath.ShortestPath.get(i+1)==40){
                showPath(line60);
            }
            else if(ShortestPath.ShortestPath.get(i)==40 && ShortestPath.ShortestPath.get(i+1)==39){
                showPath(line60);
            }
            if(ShortestPath.ShortestPath.get(i)==39 && ShortestPath.ShortestPath.get(i+1)==58){
                showPath(line61);
            }
            else if(ShortestPath.ShortestPath.get(i)==58 && ShortestPath.ShortestPath.get(i+1)==39){
                showPath(line61);
            }
            if(ShortestPath.ShortestPath.get(i)==40 && ShortestPath.ShortestPath.get(i+1)==41){
                showPath(line62);
            }
            else if(ShortestPath.ShortestPath.get(i)==41 && ShortestPath.ShortestPath.get(i+1)==40){
                showPath(line62);
            }
            if(ShortestPath.ShortestPath.get(i)==41 && ShortestPath.ShortestPath.get(i+1)==42){
                showPath(line63);
            }
            else if(ShortestPath.ShortestPath.get(i)==42 && ShortestPath.ShortestPath.get(i+1)==41){
                showPath(line63);
            }
            if(ShortestPath.ShortestPath.get(i)==41 && ShortestPath.ShortestPath.get(i+1)==43){
                showPath(line64);
            }
            else if(ShortestPath.ShortestPath.get(i)==43 && ShortestPath.ShortestPath.get(i+1)==41){
                showPath(line64);
            }
            if(ShortestPath.ShortestPath.get(i)==43 && ShortestPath.ShortestPath.get(i+1)==44){
                showPath(line65);
            }
            else if(ShortestPath.ShortestPath.get(i)==44 && ShortestPath.ShortestPath.get(i+1)==43){
                showPath(line65);
            }
            if(ShortestPath.ShortestPath.get(i)==43 && ShortestPath.ShortestPath.get(i+1)==60){
                showPath(line66);
            }
            else if(ShortestPath.ShortestPath.get(i)==60 && ShortestPath.ShortestPath.get(i+1)==43){
                showPath(line66);
            }
            if(ShortestPath.ShortestPath.get(i)==44 && ShortestPath.ShortestPath.get(i+1)==45){
                showPath(line67);
            }
            else if(ShortestPath.ShortestPath.get(i)==45 && ShortestPath.ShortestPath.get(i+1)==44){
                showPath(line67);
            }
            if(ShortestPath.ShortestPath.get(i)==44 && ShortestPath.ShortestPath.get(i+1)==62){
                showPath(line68);
            }
            else if(ShortestPath.ShortestPath.get(i)==62 && ShortestPath.ShortestPath.get(i+1)==44){
                showPath(line68);
            }
            if(ShortestPath.ShortestPath.get(i)==45 && ShortestPath.ShortestPath.get(i+1)==46){
                showPath(line69);
            }
            else if(ShortestPath.ShortestPath.get(i)==46 && ShortestPath.ShortestPath.get(i+1)==45){
                showPath(line69);
            }
            if(ShortestPath.ShortestPath.get(i)==46 && ShortestPath.ShortestPath.get(i+1)==47){
                showPath(line70);
            }
            else if(ShortestPath.ShortestPath.get(i)==47 && ShortestPath.ShortestPath.get(i+1)==46){
                showPath(line70);
            }
            if(ShortestPath.ShortestPath.get(i)==46 && ShortestPath.ShortestPath.get(i+1)==64){
                showPath(line71);
            }
            else if(ShortestPath.ShortestPath.get(i)==64 && ShortestPath.ShortestPath.get(i+1)==46){
                showPath(line71);
            }
            if(ShortestPath.ShortestPath.get(i)==47 && ShortestPath.ShortestPath.get(i+1)==48){
                showPath(line72);
            }
            else if(ShortestPath.ShortestPath.get(i)==48 && ShortestPath.ShortestPath.get(i+1)==47){
                showPath(line72);
            }
            if(ShortestPath.ShortestPath.get(i)==48 && ShortestPath.ShortestPath.get(i+1)==49){
                showPath(line73);
            }
            else if(ShortestPath.ShortestPath.get(i)==49 && ShortestPath.ShortestPath.get(i+1)==48){
                showPath(line73);
            }
            if(ShortestPath.ShortestPath.get(i)==48 && ShortestPath.ShortestPath.get(i+1)==65){
                showPath(line74);
            }
            else if(ShortestPath.ShortestPath.get(i)==65 && ShortestPath.ShortestPath.get(i+1)==48){
                showPath(line74);
            }
            if(ShortestPath.ShortestPath.get(i)==49 && ShortestPath.ShortestPath.get(i+1)==50){
                showPath(line75);
            }
            else if(ShortestPath.ShortestPath.get(i)==50 && ShortestPath.ShortestPath.get(i+1)==49){
                showPath(line75);
            }
            if(ShortestPath.ShortestPath.get(i)==49 && ShortestPath.ShortestPath.get(i+1)==51){
                showPath(line76);
            }
            else if(ShortestPath.ShortestPath.get(i)==51 && ShortestPath.ShortestPath.get(i+1)==49){
                showPath(line76);
            }
            if(ShortestPath.ShortestPath.get(i)==52 && ShortestPath.ShortestPath.get(i+1)==53){
                showPath(line77);
            }
            else if(ShortestPath.ShortestPath.get(i)==53 && ShortestPath.ShortestPath.get(i+1)==52){
                showPath(line77);
            }
            if(ShortestPath.ShortestPath.get(i)==53 && ShortestPath.ShortestPath.get(i+1)==54){
                showPath(line78);
            }
            else if(ShortestPath.ShortestPath.get(i)==54 && ShortestPath.ShortestPath.get(i+1)==53){
                showPath(line78);
            }
            if(ShortestPath.ShortestPath.get(i)==54 && ShortestPath.ShortestPath.get(i+1)==55){
                showPath(line79);
            }
            else if(ShortestPath.ShortestPath.get(i)==55 && ShortestPath.ShortestPath.get(i+1)==54){
                showPath(line79);
            }
            if(ShortestPath.ShortestPath.get(i)==55 && ShortestPath.ShortestPath.get(i+1)==56){
                showPath(line80);
            }
            else if(ShortestPath.ShortestPath.get(i)==56 && ShortestPath.ShortestPath.get(i+1)==55){
                showPath(line80);
            }
            if(ShortestPath.ShortestPath.get(i)==56 && ShortestPath.ShortestPath.get(i+1)==57){
                showPath(line81);
            }
            else if(ShortestPath.ShortestPath.get(i)==57 && ShortestPath.ShortestPath.get(i+1)==56){
                showPath(line81);
            }
            if(ShortestPath.ShortestPath.get(i)==57 && ShortestPath.ShortestPath.get(i+1)==58){
                showPath(line82);
            }
            else if(ShortestPath.ShortestPath.get(i)==58 && ShortestPath.ShortestPath.get(i+1)==57){
                showPath(line82);
            }
            if(ShortestPath.ShortestPath.get(i)==58 && ShortestPath.ShortestPath.get(i+1)==59){
                showPath(line83);
            }
            else if(ShortestPath.ShortestPath.get(i)==59 && ShortestPath.ShortestPath.get(i+1)==58){
                showPath(line83);
            }
            if(ShortestPath.ShortestPath.get(i)==59 && ShortestPath.ShortestPath.get(i+1)==60){
                showPath(line84);
            }
            else if(ShortestPath.ShortestPath.get(i)==60 && ShortestPath.ShortestPath.get(i+1)==59){
                showPath(line84);
            }
            if(ShortestPath.ShortestPath.get(i)==60 && ShortestPath.ShortestPath.get(i+1)==61){
                showPath(line85);
            }
            else if(ShortestPath.ShortestPath.get(i)==61 && ShortestPath.ShortestPath.get(i+1)==60){
                showPath(line85);
            }
            if(ShortestPath.ShortestPath.get(i)==61 && ShortestPath.ShortestPath.get(i+1)==62){
                showPath(line86);
            }
            else if(ShortestPath.ShortestPath.get(i)==62 && ShortestPath.ShortestPath.get(i+1)==61){
                showPath(line86);
            }
            if(ShortestPath.ShortestPath.get(i)==62 && ShortestPath.ShortestPath.get(i+1)==63){
                showPath(line87);
            }
            else if(ShortestPath.ShortestPath.get(i)==63 && ShortestPath.ShortestPath.get(i+1)==62){
                showPath(line87);
            }
            if(ShortestPath.ShortestPath.get(i)==63 && ShortestPath.ShortestPath.get(i+1)==64){
                showPath(line88);
            }
            else if(ShortestPath.ShortestPath.get(i)==64 && ShortestPath.ShortestPath.get(i+1)==63){
                showPath(line88);
            }
            if(ShortestPath.ShortestPath.get(i)==64 && ShortestPath.ShortestPath.get(i+1)==65){
                showPath(line89);
            }
            else if(ShortestPath.ShortestPath.get(i)==65 && ShortestPath.ShortestPath.get(i+1)==64){
                showPath(line89);
            }
            if(ShortestPath.ShortestPath.get(i)==65 && ShortestPath.ShortestPath.get(i+1)==66){
                showPath(line90);
            }
            else if(ShortestPath.ShortestPath.get(i)==66 && ShortestPath.ShortestPath.get(i+1)==65){
                showPath(line90);
            }
        }
        distance.setVisible(true);
        estimatedTime.setVisible(true);
        distance.setText("Distance to the intended location: "+ShortestPath.Distance);
        double time = ShortestPath.Distance + TotalTraffic;
        estimatedTime.setText(String.format("Estimated time to the intended location: %.2f mins", time));
    }
    public void back(){
        go.setVisible(true);
        back.setVisible(false);
        map2.setVisible(false);
        map1.setVisible(true);
        startLabel.setVisible(true);
        endLabel.setVisible(true);
        start.setVisible(true);
        end.setVisible(true);
        distance.setVisible(false);
        estimatedTime.setVisible(false);
        line1.setVisible(false);
        line2.setVisible(false);
        line3.setVisible(false);
        line4.setVisible(false);
        line5.setVisible(false);
        line6.setVisible(false);
        line7.setVisible(false);
        line8.setVisible(false);
        line9.setVisible(false);
        line10.setVisible(false);
        line11.setVisible(false);
        line12.setVisible(false);
        line13.setVisible(false);
        line14.setVisible(false);
        line15.setVisible(false);
        line16.setVisible(false);
        line17.setVisible(false);
        line18.setVisible(false);
        line19.setVisible(false);
        line20.setVisible(false);
        line21.setVisible(false);
        line22.setVisible(false);
        line23.setVisible(false);
        line24.setVisible(false);
        line25.setVisible(false);
        line26.setVisible(false);
        line27.setVisible(false);
        line28.setVisible(false);
        line29.setVisible(false);
        line30.setVisible(false);
        line31.setVisible(false);
        line32.setVisible(false);
        line33.setVisible(false);
        line34.setVisible(false);
        line35.setVisible(false);
        line36.setVisible(false);
        line37.setVisible(false);
        line38.setVisible(false);
        line39.setVisible(false);
        line40.setVisible(false);
        line41.setVisible(false);
        line42.setVisible(false);
        line43.setVisible(false);
        line44.setVisible(false);
        line45.setVisible(false);
        line46.setVisible(false);
        line47.setVisible(false);
        line48.setVisible(false);
        line49.setVisible(false);
        line50.setVisible(false);
        line51.setVisible(false);
        line52.setVisible(false);
        line53.setVisible(false);
        line54.setVisible(false);
        line55.setVisible(false);
        line56.setVisible(false);
        line57.setVisible(false);
        line58.setVisible(false);
        line59.setVisible(false);
        line60.setVisible(false);
        line61.setVisible(false);
        line62.setVisible(false);
        line63.setVisible(false);
        line64.setVisible(false);
        line65.setVisible(false);
        line66.setVisible(false);
        line67.setVisible(false);
        line68.setVisible(false);
        line69.setVisible(false);
        line70.setVisible(false);
        line71.setVisible(false);
        line72.setVisible(false);
        line73.setVisible(false);
        line74.setVisible(false);
        line75.setVisible(false);
        line76.setVisible(false);
        line77.setVisible(false);
        line78.setVisible(false);
        line79.setVisible(false);
        line80.setVisible(false);
        line81.setVisible(false);
        line82.setVisible(false);
        line83.setVisible(false);
        line84.setVisible(false);
        line85.setVisible(false);
        line86.setVisible(false);
        line87.setVisible(false);
        line88.setVisible(false);
        line89.setVisible(false);
        line90.setVisible(false);
    }
    public static void showPath(Line line){
        line.setVisible(true);
        float traffic = rand.nextFloat();
        TotalTraffic+=traffic;
        if(traffic<=0.33)
            line.setStroke(Color.BLUE);
        else if(traffic<=0.66 && traffic>0.33)
            line.setStroke(Color.ORANGE);
        else
            line.setStroke(Color.RED);
    }
}